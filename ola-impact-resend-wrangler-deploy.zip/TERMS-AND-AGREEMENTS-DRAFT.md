# OLA! Website Terms & Conditions and Multi-Party Participation & Supply Framework Agreement

**DRAFT FOR REVIEW — prepared 7 November 2026. Not effective, not an offer, and not for signature.** This document needs review and approval by Rovaya Group (Pty) Ltd and a South African commercial attorney before publication or use. It does not create an escrow service, credit facility, consignment, inventory-title transfer, lease, or supply order.

> This is drafting material based on the business outline supplied by the owner. It is not legal advice. Bracketed items and commercial details must be completed and confirmed by counsel and the parties.

## Part I — Proposed OLA! Website Terms & Conditions

### 1. Platform and parties

OLA! is the online platform operated by **Rovaya Group (Pty) Ltd**, trading as **OLA!** (“Rovaya”, “OLA!” or “the Platform”). These proposed Website Terms apply to use of the OLA! app, applications submitted through it, and supplier or opportunity information uploaded for review. The draft assumes South African law applies; counsel must confirm the governing law, regulatory position, required notices and venue before publication.

### 2. Supplier classes

OLA! distinguishes between:

- **Local/Micro-Suppliers:** local businesses, co-operatives and smaller suppliers using the standard supplier application and directory terms in this document.
- **Enterprise/Wholesale Partners:** wholesalers and corporate FMCG suppliers. These partners are subject to the same baseline Platform terms and, before wholesale trade begins, a separate written Master Distribution Agreement (“MDA”) or other signed supply schedule with Rovaya.

An MDA governs its specified wholesale commercial matters only. If a signed MDA directly conflicts with these Website Terms on a matter it expressly covers, the MDA controls for that matter and those signatories. A registration, listing, conversation or application does not itself constitute an MDA or commit any party to buy or supply goods.

### 3. OLA!’s proposed aggregator role; no automatic escrow or credit

Rovaya intends OLA! to coordinate participating wholesale opportunities as a central commercial aggregator, rather than making an individual shop operator responsible for a corporate wholesale account merely because the operator uses the Platform. Any ordering, credit, title-retention, consignment, payment-administration, settlement or escrow arrangement must be specifically described in a separate, executed agreement, with the relevant parties, funds flow, fees, risk allocation and controls identified. **The Website and app do not currently collect or process payments. Registration does not appoint OLA! as an escrow agent, create an escrow account, transfer title to stock, extend credit, or authorize OLA! to hold or disburse funds.** Any future arrangement requires separate legal and operational approval.

### 4. Supplier catalogue and visibility permission

When submitting supplier information, the supplier may authorize OLA! to host and display the supplier’s business name, product and SKU descriptions, submitted product images, prices and availability or stock information to verified OLA! operators and shop-space owners for discovery, sourcing and introduction purposes. This permission applies only to the information the supplier submits for that purpose and does not make confidential or unsubmitted information public. A supplier remains responsible for the accuracy and timely updating of the information it provides. Public display is subject to review and the Platform’s technical availability; no listing guarantees demand, an order, a particular sales volume or stock availability.

### 5. Applications, listings and orders

Applications may be reviewed before publication. Submitting an application is not an offer accepted by OLA!, a purchase order, a promise to supply, or a guarantee of approval. Prices, tax, delivery, order acceptance, returns, warranties, title, risk of loss, payment timing, platform fees, credit and stock rotation must be agreed in a separate written transaction document or signed schedule before a wholesale order is binding. No commercial term is implied solely from information shown in a listing or calculator.

### 6. Operators and premises

An operator’s duties concerning stock custody, daily reconciliation, permitted retail pricing, insurance, shrinkage, commission, deductions and audit access apply only if expressly set out in a separate operator agreement signed by that operator. A shop-space owner’s permission, rent, access, repairs, occupation and tenancy terms must be addressed in a separate lease or site agreement. These Website Terms do not create a lease, employment relationship, franchise, agency or partnership.

### 7. Submission authority and conduct

A person submitting information confirms that they are authorized to do so for the person or business named, that the information is accurate to the best of their knowledge, and that they will not knowingly submit unlawful, misleading or third-party material they have no right to share. OLA! may restrict, correct, remove or decline a listing or application in accordance with the final published terms and applicable law.

### 8. Changes and precedence

The final Terms will state an effective date and version and explain how material changes are notified. Signed role-specific agreements take precedence only for matters they expressly address and only between their signatories. A South African attorney should confirm consumer, privacy, competition, payment-services and other applicable requirements before these draft Terms are used.

### Proposed general application consent

> **I have read and accept the OLA! Terms & Conditions applicable to my selected role, and confirm that the information I submit is accurate to the best of my knowledge.**

### Proposed supplier-specific consent

> **I confirm that I am authorized to apply for this supplier and accept the Supplier Terms. I authorize Rovaya Group (Pty) Ltd, trading as OLA!, to display the supplier business name and the product/SKU descriptions, images, prices and availability information I submit to verified OLA! operators and shop-space owners for sourcing and introductions. I understand that supplier registration does not create a supply order, credit, consignment, escrow, inventory-title or settlement arrangement; an Enterprise/Wholesale Partner must enter a separate signed agreement for any such arrangement.**

The app should capture the accepted Terms version and timestamp, plus the chosen supplier class and supplier-specific acceptance timestamp, with each application. Supplier classes should be stored as `local_micro` and `enterprise_wholesale`.

## Part II — Multi-Party Participation & Supply Framework Agreement

### Draft status and use

**DRAFT ONLY — NOT FOR SIGNATURE OR PERFORMANCE.** This proposed framework is intended to bring OLA!, suppliers, operators and shop-space owners under one coordinated document structure while keeping each party’s obligations role-specific. Counsel may recommend splitting it into separate bilateral or tripartite agreements. No participant is bound until the final agreement and each applicable schedule have been reviewed, completed and signed by the relevant parties.

### 1. Parties and role accession

This draft contemplates the following participants, with legal names and addresses to be inserted in the final document:

1. **Platform/Coordinator:** Rovaya Group (Pty) Ltd, trading as OLA! (“OLA!”).
2. **Supplier:** the named Local/Micro-Supplier or Enterprise/Wholesale Partner, with its class selected in Schedule A.
3. **Operator:** the named person or business operating the specific shop, if participating under Schedule B.
4. **Shop-space owner:** the named owner or authorized lessor of the premises, if participating under Schedule C.

A party signs only the role schedule(s) that apply to it. A supplier does not take on landlord duties; a shop-space owner does not take on supplier credit or stock duties; and an operator is not responsible for a supplier’s corporate account merely by joining OLA!. Any additional guarantor, lender, payment provider or distributor must be separately named, reviewed and signed in the final documents.

### 2. Purpose and conditions precedent

The proposed framework provides a structure for introducing approved products and stock to participating OLA! shops, coordinating site and operator participation, and recording agreed commercial terms. Before any delivery or sale, the parties must complete the applicable schedules, identify the specific site and products, agree prices and tax treatment, confirm who accepts orders, and complete all required regulatory, safety, insurance and payment checks. The app application alone is not an order or contract for supply.

### 3. OLA! coordination role and payment safeguards

If and only if the signed commercial schedule authorizes it, OLA! may coordinate supplier introductions, aggregated orders, inventory visibility and payment administration. The schedule must state the payment provider or bank account, legal holder of funds, reconciliation process, settlement timing, fees, error handling, refunds and insolvency treatment. No party may describe OLA! as holding funds in escrow or as providing regulated financial services unless counsel has confirmed the structure and the parties have executed all required agreements. Until then, OLA! does not receive or safeguard wholesale purchase funds through the app.

### 4. Supplier obligations — Schedule A

The supplier identifies its class as Local/Micro-Supplier or Enterprise/Wholesale Partner; confirms authority to supply; supplies accurate business, SKU, price, tax, product, image, stock and delivery information; maintains any required product approvals, labelling, warranties and traceability; notifies OLA! of recalls, safety issues, price changes and material availability changes; and supplies invoices and delivery records as agreed. The supplier grants only the limited catalogue-display permission stated in the final schedule. Products, minimum orders, service levels, territory, exclusivity and returns must be specifically listed; none is implied by this framework.

### 5. Operator obligations — Schedule B

The operator’s responsibilities must be completed in the signed schedule, including the site, authorized product range, receiving checks, storage conditions, sales records, stock counts and escalation process. Daily reconciliation, pricing restrictions, custody standards, shrinkage tolerances, insurance, security deposits and any deductions from commissions are **not** imposed by this draft; they become binding only if their exact method, limits, evidence, dispute process and amounts are stated in an operator agreement signed by the operator and reviewed by counsel. No deduction may be inferred from an example percentage in a proposal.

### 6. Shop-space owner obligations — Schedule C

The owner confirms its authority to permit the named operator to use the identified premises on the terms of a separate lease or written site permission. Schedule C must identify permitted activities, access hours, utilities, safety responsibilities, inspection notice, repairs, insurance and termination. This framework does not itself grant occupation, set rent, vary a lease or make the owner liable for inventory, supplier credit or operator performance.

### 7. Orders, price, title, risk and settlement — Schedule D

For each pilot or supply channel, the parties must complete: accepted purchase-order process; product and SKU list; wholesale and retail prices; VAT/tax treatment; delivery, receiving and returns; who owns stock before and after each sale; risk of loss and insurance; credit terms (if any); settlement flow and timetable; OLA! facilitation fees; refunds and chargebacks; and reconciliation records. **No title-retention, consignment, escrow, 24/48-hour settlement or weekly-EFT term applies unless its complete wording is set out in a final signed schedule.**

### 8. Stock rotation, inspection and records

The parties must agree in writing on expiry thresholds, damaged or short-dated goods, stock reallocation, returns, audit access, notice period, business hours, data available to each party, record-retention period and how discrepancies are investigated. Until those items are completed, this draft creates no inspection right, mandatory stock rotation or automatic liability for a stock variance.

### 9. Data, confidentiality and intellectual property

Each party may use another party’s non-public information only for the purpose and period specified in the final agreement. OLA! may show approved supplier catalogue data to verified users as authorized in the Supplier Terms. Confidentiality exceptions, retention/deletion, security, permitted contact, privacy notices and any cross-border processing must be reviewed and completed by counsel. Each party retains its pre-existing trademarks, product materials and intellectual property; any broader licence must be written in the relevant schedule.

### 10. Warranties, liability and insurance

The parties must specify product warranties, recalls, consumer complaints, insurance limits, indemnities, liability caps, exclusions, negligence standards and responsibility for third-party claims in the final documents. This draft creates no indemnity, guarantee, personal surety or uncapped liability. Mandatory statutory rights cannot be excluded by this draft.

### 11. Term, suspension and termination

The final agreement must specify its start date, pilot period (if any), renewal, notice, immediate suspension triggers, treatment of open orders, stock return or purchase, final reconciliation, data deletion and surviving provisions. OLA! may propose pausing new orders for a material safety or compliance concern, but any contractual right and process must be finalized by counsel and accepted by the affected parties.

### 12. Disputes, governing law and notices

Proposed governing law: the law of the Republic of South Africa, subject to attorney confirmation. The final agreement must state the notice addresses, escalation contacts, dispute-resolution steps, court or arbitration forum, language, service method and any applicable consumer-protection or competition-law terms. None is finalized by this draft.

### 13. Completion and signatures

Before signature, insert each legal entity’s registered name, registration number, physical and notice address, authorized representative and selected role schedule; attach final commercial schedules; record the version and effective date; and obtain South African commercial-law review. Each signatory should receive the same final version. **This draft must not be signed or treated as effective.**
