import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

const siteOrigin = 'https://rovaya.co.za';
const outputDir = 'dist';
const routes = {
  '/community': {
    title: 'Town Hall | OLA! — Ikasi Elethu',
    description: 'Visit the OLA! town hall to connect with local operators, shop-space owners, product suppliers and supporters. OLA! is by Rovaya Group (Pty) Ltd.',
    heading: 'OLA! Town Hall — Ikasi Elethu',
    body: 'Connect and share with the OLA! community. The town hall is a public space for conversations between local operators, shop-space owners, product suppliers and supporters.',
  },
  '/marketplace': {
    title: 'Shop Spaces and Suppliers | OLA! — Ikasi Elethu',
    description: 'Explore approved shop-space listings and product suppliers in the OLA! community marketplace by Rovaya Group (Pty) Ltd.',
    heading: 'OLA! Shop Spaces and Suppliers',
    body: 'Explore the OLA! marketplace for approved local shop spaces and product suppliers. OLA! connects community opportunities under the Ikasi Elethu slogan.',
  },
  '/join': {
    title: 'Join the OLA! Community | Ikasi Elethu',
    description: 'Take part in OLA!: list a shop space, apply to operate a local shop, supply products, or register your interest with Rovaya Group (Pty) Ltd.',
    heading: 'Take part in OLA! — Ikasi Elethu',
    body: 'Choose how you would like to take part: list a shop space, apply to operate, apply as a product supplier, or register non-binding interest.',
  },
  '/pilot': {
    title: 'OLA! Community Pilot | Ikasi Elethu',
    description: 'Learn about the OLA! community pilot, connecting local spaces, operators and suppliers through Rovaya Group (Pty) Ltd.',
    heading: 'OLA! Community Pilot',
    body: 'OLA! brings together shop spaces, operators and product suppliers. Pilot information shown in the app depends on available verified records.',
  },
  '/calculator': {
    title: 'OLA! Scenario Calculator | Ikasi Elethu',
    description: 'Explore an illustrative OLA! value split using your own assumptions. The calculator is a scenario tool, not financial advice.',
    heading: 'Explore an OLA! Scenario',
    body: 'Use your own sales and percentage assumptions to explore an illustrative scenario. Nothing is prefilled, and the calculation is not a forecast or agreed commercial term.',
  },
  '/admin': {
    title: 'OLA! Admin Sign-in | Rovaya Group',
    description: 'Restricted administration sign-in for authorized OLA! administrators at Rovaya Group (Pty) Ltd.',
    heading: 'OLA! Admin Sign-in',
    body: 'This area is restricted to explicitly authorized OLA! administrators.',
  },
};

const baseHtml = await readFile(join(outputDir, 'index.html'), 'utf8');
const escapeAttribute = (value) => value.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');

for (const [route, page] of Object.entries(routes)) {
  const canonical = `${siteOrigin}${route}`;
  let html = baseHtml
    .replace(/<title>[^<]*<\/title>/, `<title>${escapeAttribute(page.title)}</title>`)
    .replace(/(<meta name="description" content=")[^"]*("\s*\/?>)/, `$1${escapeAttribute(page.description)}$2`)
    .replace(/(<meta name="robots" content=")[^"]*("\s*\/?>)/, '$1noindex,follow$2')
    .replace(/(<link rel="canonical" href=")[^"]*("\s*\/?>)/, `$1${canonical}$2`)
    .replace(/(<meta property="og:title" content=")[^"]*("\s*\/?>)/, `$1${escapeAttribute(page.title)}$2`)
    .replace(/(<meta property="og:description" content=")[^"]*("\s*\/?>)/, `$1${escapeAttribute(page.description)}$2`)
    .replace(/(<meta property="og:url" content=")[^"]*("\s*\/?>)/, `$1${canonical}$2`)
    .replace(/(<meta name="twitter:title" content=")[^"]*("\s*\/?>)/, `$1${escapeAttribute(page.title)}$2`)
    .replace(/(<meta name="twitter:description" content=")[^"]*("\s*\/?>)/, `$1${escapeAttribute(page.description)}$2`);

  const rootStart = html.indexOf('<div id="root">');
  const rootEnd = html.indexOf('</div>', rootStart);
  if (rootStart < 0 || rootEnd < 0) {
    throw new Error(`Could not find the application shell to prerender ${route}`);
  }
  const fallback = `\n      <main><header><p>Rovaya Group (Pty) Ltd presents</p><h1>${page.heading}</h1><p>OLA! — Ikasi Elethu</p></header><section><h2>${page.title}</h2><p>${page.body}</p><p><a href="/">Visit OLA! home</a> · <a href="/community">Town hall</a> · <a href="/marketplace">Shop spaces and suppliers</a></p></section></main>\n    `;
  html = `${html.slice(0, rootStart)}<div id="root">${fallback}</div>${html.slice(rootEnd + '</div>'.length)}`;
  const destination = join(outputDir, route.slice(1), 'index.html');
  await mkdir(dirname(destination), { recursive: true });
  await writeFile(destination, html);
  console.log(`Prerendered ${route} (${page.title})`);
}
