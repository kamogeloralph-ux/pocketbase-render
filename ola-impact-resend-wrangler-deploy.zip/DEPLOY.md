# OLA! — verified app and release guide

This project is a Vite/React static frontend backed by the connected OLA Supabase project. The public app shows only approved, non-sample listings. Submissions remain private for an administrator to review; the app does not take payments or approve applicants automatically.

## Connected services and current state

- **Supabase:** OLA project `rjpfdsjffddyoaezdznb` at `https://rjpfdsjffddyoaezdznb.supabase.co`.
- **Cloudflare Pages:** Direct Upload project `ola`, hosted at `ola-827.pages.dev` and attached to `rovaya.co.za`; production branch `main`. No DNS changes are needed.
- **Public listing data:** Two approved, non-sample shops currently have galleries, and both photo URLs returned HTTP 200 during the source verification. There are no approved product-supplier records yet. The shop rows `OLA-107` and `OLA-108` appear at the same address/area; the admin console flags this possible duplicate. Neither record was hidden or deleted. The owner must choose which record to keep, or confirm that both are intentional.
- **Pending submissions:** There are currently no applications awaiting review. No test application, enquiry, shop or supplier record was inserted.

## Admin workspace

`/admin` uses the existing Supabase email/password sign-in and the private `ola_admins` UID allowlist. The owner-supplied Auth UID is present in that allowlist. Only allowlisted administrators are authorized by the UI and `public.is_admin()` database checks.

The console provides full-field search/view plus create, edit and delete actions for `join_applications`, `shops`, `suppliers`, `hardware_assets`, `community_posts`, `community_comments`, `shop_enquiries`, and `pilot_stats`. Pending applications also have explicit approve/reject actions. It is not intended to edit the security allowlist itself. Table writes use authenticated grants with RLS admin policies; public users cannot read application or enquiry rows. The anonymous REST check returned zero application and enquiry rows.

## Uploads, approval and supplier galleries

New tuckshop and product photos upload into the private `join-photos` bucket beneath `private/`. Public applicants can insert only into that private prefix. An allowlisted admin can review the image using a signed URL. On approval, the admin console copies the image to public `shop-photos` and passes only the new public path to the transaction-safe `review_join_application` RPC; the RPC rejects private paths. Rejection leaves the original photo private. Anonymous users cannot upload into the public shop-photo bucket.

Approved shop galleries are rendered as real, clickable photos on marketplace cards and detail pages and as previews while a product supplier selects a shop. Approved product-supplier galleries render in the supplier catalogue. Applicant contact fields are never copied into public shop/supplier listing rows.

## Branding and terminology

The header, footer, favicon, PWA icons, social artwork and project logo metadata use the OLA assets supplied in the original source. The public-facing product maker language has been replaced by “product supplier” terminology.

## Build and local preview

Use the project URL and the browser-safe Supabase anon/publishable key only. `.env.local` is ignored and intentionally excluded from the source ZIP; never add a `service_role` key to the Vite build or archive.

```dotenv
VITE_SUPABASE_URL=https://rjpfdsjffddyoaezdznb.supabase.co
VITE_SUPABASE_ANON_KEY=<browser-safe key>
```

```bash
npm ci
npm run build
npm run preview -- --host 0.0.0.0
```

A non-live, unconfigured or failed backend is shown honestly; the frontend does not substitute fabricated data. `public/manus-routes.json` is copied into `dist` and includes `/admin`.

## Database migrations

The source includes the verified existing-schema migrations for the OLA project, including the add-only expected opening date, UID allowlist/admin policies, product-supplier gallery fields, admin CRUD grants, safe photo-review RPC and bucket policies. The latest additions are:

- `20261106174500_private_submission_photo_publishing.sql`
- `20261106175000_photo_bucket_privacy_policies.sql`
- `20261106175500_admin_crud_and_private_photo_read.sql`

They have been applied to the connected OLA project. The authenticated role has only the RLS-scoped access needed for the console; table RLS is enabled, the admin-only ALL policies are present, and the private `join-photos` bucket can be read only by admins. The review RPC is not executable by `anon` and checks `public.is_admin()` before acting.

## Publish to Cloudflare Pages

The corrected static site is built in `dist/`. The connected Cloudflare credential could inspect the existing Pages project but does not have the required asset-upload permission, so this task did not publish a deployment or change DNS. To release manually, open **Workers & Pages → ola → Create a new deployment**, choose the **production** environment, and upload the versioned Pages ZIP supplied with this update (or the contents of `dist/`). This project is Direct Upload; the ZIP is rooted at the site files and does not contain `.env.local`.

The static files already contain the browser-safe Supabase configuration used for this build. Do not rely on a Cloudflare-side Vite rebuild; upload the prebuilt distribution. The live site remains on its previous frontend until this deployment is made.

## Remaining owner decisions

- Decide whether OLA-107 and OLA-108 are both intentional or whether one should be removed. No destructive change has been made.
- Publish the versioned `dist` bundle to production Pages to activate the full admin workspace, restored logo and new private-upload path on the live site.
- Consider adding server-verified abuse protection such as Turnstile/rate limiting before broad public promotion. This is not a substitute for the current RLS controls.

## Resend registration email notifications
The registration forms continue to save the application to Supabase first. After a successful save, the browser calls `/api/submit`; if email delivery fails, the saved application remains intact and the form reports that the notification failed. The function only emails the configured OLA notification inbox, limits accepted fields by role, and escapes user-entered values before building HTML. Set `RESEND_API_KEY` as a **Secret** for the Pages project's **Production** environment; it is used only by the server-side function and must never be added to a `VITE_` variable or the static build. The function sends from `OLA! Platform <alerts@rovaya.co.za>` to `sarecruiters.directory@gmail.com`.

This Pages project uses Direct Upload. Cloudflare's dashboard drag-and-drop upload does not compile a `functions/` directory. The supplied deployment package includes a prebuilt `dist/` folder plus the root-level `functions/` folder. From the extracted project root, where `functions/` is located, deploy it with Wrangler:
```bash
npx wrangler login
npx wrangler pages deploy dist --project-name ola --branch main
```
Wrangler requires Cloudflare login and Pages deployment permissions. The `RESEND_API_KEY` must already be saved as a Secret in the Cloudflare Pages project's Production environment. Do not upload this package through dashboard drag-and-drop or deploy only `dist/`; those methods would leave `/api/submit` unavailable. For a future rebuild, create `.env.production.local` with the browser-safe `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`, then run `npm ci && npm run build`; this env file is ignored and must not contain `RESEND_API_KEY`. Official guidance: https://developers.cloudflare.com/pages/get-started/direct-upload/ and https://developers.cloudflare.com/pages/functions/get-started/.
