# OLA! Search visibility

The intended public and canonical site is **https://rovaya.co.za/**. The brand is **OLA!**, the slogan is **Ikasi Elethu**, and the publisher is **Rovaya Group (Pty) Ltd**.

The built site contains a descriptive homepage title and description, canonical and social metadata, Organization/WebSite structured data, and a text-bearing homepage in the initial HTML. The build prerenders each existing app route with a unique title and description. Only the homepage is intended for Google indexing; app views are marked `noindex,follow`, including `/admin` and `/join`. `robots.txt` permits crawling and points to the root `sitemap.xml`, which lists the canonical homepage only.

## Submit to Google

After the SEO build is deployed to the Cloudflare Pages project attached to `rovaya.co.za`:

1. Open [Google Search Console](https://search.google.com/search-console/).
2. Add the **Domain** property `rovaya.co.za` and verify it using the DNS TXT record Google provides. DNS verification is performed in the authoritative DNS provider (Cloudflare for the current site setup); use Google's exact token and do not reuse a token from another property.
3. In that verified property, submit `https://rovaya.co.za/sitemap.xml` under **Sitemaps**.
4. Use **URL Inspection** for `https://rovaya.co.za/` and request indexing if Google reports it is eligible.

Sitemap submission and an indexing request are signals, not guarantees or promises of a ranking. Google controls crawl and index timing. Refer to Google's [sitemap guidance](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap) and [Search Console property verification guide](https://support.google.com/webmasters/answer/34592?hl=en).

## Release note

This SEO work is prepared in the project build and deployment archive. The current public domain must serve the new build before Google's crawler can see these updates. Google Search Console ownership verification and sitemap submission are separate account-level steps and require the verified owner’s Google access and the DNS verification token issued by Google.
