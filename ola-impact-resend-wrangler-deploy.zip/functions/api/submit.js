const ROLE_LABELS = {
  landlord: 'Shop-space owner',
  operator: 'Shop operator',
  supplier: 'Product supplier',
  investor: 'Supporter / investor',
};

const DETAIL_LABELS = {
  landlord: {
    email: 'Contact email',
    shopAddress: 'Shop address',
    approximateSize: 'Approximate size',
    expectedRent: 'Expected rent',
    expectedOpening: 'Expected opening date',
  },
  operator: {
    email: 'Contact email',
    experience: 'Experience',
  },
  supplier: {
    email: 'Contact email',
    company: 'Company',
    product: 'Products supplied',
    interestedShop: 'Interested shop',
  },
  investor: {
    email: 'Contact email',
    nonBindingPledgeInterest: 'Non-binding pledge interest',
  },
};

const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  },
});

const cleanText = (value, maxLength) => typeof value === 'string'
  ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, maxLength)
  : '';

const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
}[character]));

export async function onRequestPost({ request, env }) {
  const origin = request.headers.get('Origin');
  if (!origin || origin !== new URL(request.url).origin) {
    return json({ success: false, error: 'Request origin is not allowed.' }, 403);
  }

  const contentType = request.headers.get('Content-Type') || '';
  if (!contentType.toLowerCase().startsWith('application/json')) {
    return json({ success: false, error: 'Expected an application/json request.' }, 415);
  }

  const contentLength = Number(request.headers.get('Content-Length') || 0);
  if (contentLength > 12_000) {
    return json({ success: false, error: 'Request is too large.' }, 413);
  }

  let data;
  try {
    const rawBody = await request.text();
    if (new TextEncoder().encode(rawBody).byteLength > 12_000) {
      return json({ success: false, error: 'Request is too large.' }, 413);
    }
    data = JSON.parse(rawBody);
  } catch {
    return json({ success: false, error: 'Invalid JSON request.' }, 400);
  }

  const role = cleanText(data?.role, 20).toLowerCase();
  if (!Object.hasOwn(ROLE_LABELS, role)) {
    return json({ success: false, error: 'Unsupported registration role.' }, 400);
  }

  const name = cleanText(data?.name, 120);
  if (!name) return json({ success: false, error: 'Name is required.' }, 400);

  const phone = cleanText(data?.phone, 60);
  const location = cleanText(data?.location, 160);
  const details = data?.details && typeof data.details === 'object' && !Array.isArray(data.details)
    ? data.details
    : {};

  const detailRows = Object.entries(DETAIL_LABELS[role])
    .map(([key, label]) => {
      const value = cleanText(details[key], key === 'experience' || key === 'shopAddress' ? 1500 : 250);
      return value ? `<tr><th align="left" style="padding:8px;border-bottom:1px solid #eee">${escapeHtml(label)}</th><td style="padding:8px;border-bottom:1px solid #eee">${escapeHtml(value)}</td></tr>` : '';
    })
    .filter(Boolean)
    .join('');

  const apiKey = env.RESEND_API_KEY;
  if (!apiKey) {
    return json({ success: false, error: 'Email notifications are not configured.' }, 500);
  }

  const safeName = escapeHtml(name);
  const safePhone = escapeHtml(phone || 'Not provided');
  const safeLocation = escapeHtml(location || 'Not provided');
  const subjectName = name.replace(/[\r\n]+/g, ' ').slice(0, 80);
  let resendResponse;
  try {
    resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'OLA! Platform <alerts@rovaya.co.za>',
        to: ['sarecruiters.directory@gmail.com'],
        subject: `[OLA! Registration] New ${ROLE_LABELS[role]} submission: ${subjectName}`,
        html: `<div style="font-family:Arial,sans-serif;padding:20px;color:#111;max-width:680px"><h2 style="color:#5b7d12">OLA! — Ikasi Elethu</h2><p>A new registration was saved on OLA! for administrator review.</p><table style="border-collapse:collapse;width:100%"><tr><th align="left" style="padding:8px;border-bottom:1px solid #eee">Role</th><td style="padding:8px;border-bottom:1px solid #eee">${escapeHtml(ROLE_LABELS[role])}</td></tr><tr><th align="left" style="padding:8px;border-bottom:1px solid #eee">Name / company</th><td style="padding:8px;border-bottom:1px solid #eee">${safeName}</td></tr><tr><th align="left" style="padding:8px;border-bottom:1px solid #eee">Phone</th><td style="padding:8px;border-bottom:1px solid #eee">${safePhone}</td></tr><tr><th align="left" style="padding:8px;border-bottom:1px solid #eee">Location</th><td style="padding:8px;border-bottom:1px solid #eee">${safeLocation}</td></tr>${detailRows}</table><p style="font-size:12px;color:#666;margin-top:24px">Automated notification from rovaya.co.za. Review the application in the OLA admin console.</p></div>`,
      }),
    });
  } catch {
    return json({ success: false, error: 'Email delivery failed.' }, 502);
  }

  if (!resendResponse.ok) {
    // Do not return provider response bodies to the public client.
    return json({ success: false, error: 'Email delivery failed.' }, 502);
  }

  let resendResult = {};
  try {
    resendResult = await resendResponse.json();
  } catch {
    // A successful provider response without JSON still means accepted.
  }
  return json({ success: true, id: typeof resendResult.id === 'string' ? resendResult.id : undefined });
}
