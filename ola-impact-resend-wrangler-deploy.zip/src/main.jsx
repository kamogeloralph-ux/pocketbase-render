import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  BadgeDollarSign,
  Boxes,
  Building2,
  Camera,
  Calculator,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  DoorOpen,
  Factory,
  Globe2,
  Hammer,
  HeartHandshake,
  Image,
  Landmark,
  LockKeyhole,
  LogOut,
  MapPinned,
  MapPin,
  Menu,
  Monitor,
  MessageCircle,
  PackageCheck,
  Plus,
  ReceiptText,
  Ruler,
  Search,
  Send,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Store,
  ThumbsUp,
  TrendingUp,
  UsersRound,
  WalletCards,
  X,
} from 'lucide-react';
import { isSupabaseConfigured, publicOlaImageUrl, supabase, uploadOlaImage } from './lib/supabase';
import AdminConsole from './admin/AdminConsole';
import './styles.css';

const money = (value) => `R${Number(value).toLocaleString('en-ZA', { maximumFractionDigits: 0 })}`;

const navItems = [
  { id: 'community', label: 'Town hall' },
  { id: 'overview', label: 'Overview' },
  { id: 'join', label: 'Join the hustle' },
  { id: 'marketplace', label: 'Shops & suppliers' },
  { id: 'pilot', label: 'Pilot dashboard' },
  { id: 'calculator', label: 'Margin splitter' },
];

const getViewFromPath = (pathname) => {
  const view = pathname.replace(/^\//, '').split('/')[0];
  return view === 'admin' || navItems.some((item) => item.id === view) ? view : 'overview';
};

const roles = [
  { id: 'landlord', label: 'I have a shop space', icon: Building2, accent: 'lime', detail: 'Turn unused space into a kasi business that moves.' },
  { id: 'operator', label: 'I want to operate', icon: Store, accent: 'coral', detail: 'Apply to operate a local shop and share your experience.' },
  { id: 'supplier', label: 'I supply products', icon: Factory, accent: 'sky', detail: 'Offer products to local shops and see the real spaces before you commit.' },
  { id: 'investor', label: 'I want to support OLA', icon: BadgeDollarSign, accent: 'gold', detail: 'Share non-binding interest in supporting OLA as it develops.' },
];

const formatOpenDate = (value) => value ? new Intl.DateTimeFormat('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(`${value}T00:00:00`)) : 'Date to confirm';

async function loadOlaData() {
  if (!supabase) return null;
  const [shopResult, supplierResult, hardwareResult, postResult, commentResult] = await Promise.all([
    supabase.from('shops').select('id,code,address,city,size,rent,status,score,description,hours,tags,hardware_needs,photo_views,photo_gallery,expected_opening,created_at').eq('approved', true).eq('is_sample', false).order('created_at', { ascending: false }).limit(500),
    supabase.from('suppliers').select('id,company,product,price,category,photo_gallery,shop_id,created_at').eq('approved', true).eq('is_sample', false).order('created_at', { ascending: false }).limit(500),
    supabase.from('hardware_assets').select('id,name,type,contribution,location,status,created_at').eq('approved', true).eq('is_sample', false).order('created_at', { ascending: false }).limit(500),
    supabase.from('community_posts').select('id,author,role,location,content,likes,created_at').eq('is_sample', false).order('created_at', { ascending: false }).limit(500),
    supabase.from('community_comments').select('id,post_id,author,text,created_at').order('created_at').limit(1000),
  ]);
  const firstError = [shopResult, supplierResult, hardwareResult, postResult, commentResult].find((result) => result.error)?.error;
  if (firstError) throw firstError;
  const commentsByPost = (commentResult.data || []).reduce((map, comment) => { (map[comment.post_id] ||= []).push({ id: comment.id, author: comment.author, text: comment.text }); return map; }, {});
  return {
    shops: (shopResult.data || []).map((shop) => ({
      id: shop.code || shop.id,
      databaseId: shop.id,
      address: shop.address,
      city: shop.city,
      size: shop.size,
      rent: shop.rent == null || Number(shop.rent) <= 0 ? null : Number(shop.rent),
      openDate: formatOpenDate(shop.expected_opening),
      status: shop.status,
      score: shop.score,
      suppliersSigned: null,
      supplierTarget: null,
      description: shop.description === 'New shop listing submitted for community review and field verification.' ? null : shop.description,
      hours: shop.hours === 'To be confirmed' ? null : shop.hours,
      tags: (shop.tags || []).filter((tag) => tag !== 'New listing'),
      hardwareNeeds: (shop.hardware_needs || []).filter((need) => !['Display fridge', 'Till point', 'Shelving'].includes(need) || (shop.hardware_needs || []).length !== 3),
      photoViews: (shop.photo_views || []).filter((view) => !/^Photo \d+ pending$/i.test(view)),
      photoGallery: (shop.photo_gallery || []).map(publicOlaImageUrl),
    })),
    suppliers: (supplierResult.data || []).map((supplier) => ({
      id: supplier.id,
      company: supplier.company,
      product: supplier.product,
      price: supplier.price == null ? null : Number(supplier.price),
      category: supplier.category,
      photoSubmitted: Boolean((supplier.photo_gallery || []).length),
      productPhoto: (supplier.photo_gallery || []).map(publicOlaImageUrl).find(Boolean) || null,
      photoGallery: (supplier.photo_gallery || []).map(publicOlaImageUrl).filter(Boolean),
      shopId: supplier.shop_id,
    })),
    hardware: (hardwareResult.data || []).map((item) => ({ id: item.id, name: item.name, type: item.type, contribution: item.contribution, location: item.location, status: item.status })),
    posts: (postResult.data || []).map((post) => ({ id: post.id, author: post.author, role: post.role, location: post.location, content: post.content, timestamp: new Date(post.created_at).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' }), likes: post.likes, comments: commentsByPost[post.id] || [] })),
  };
}

async function sendRegistrationNotification(payload) {
  try {
    const response = await fetch('/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.success) {
      console.error('OLA registration email notification failed:', result.error || response.status);
      return false;
    }
    return true;
  } catch (error) {
    console.error('OLA registration email notification failed:', error);
    return false;
  }
}

function App() {
  const [activeView, setActiveView] = useState(() => getViewFromPath(window.location.pathname));
  const [mobileMenu, setMobileMenu] = useState(false);
  const [activeRole, setActiveRole] = useState('landlord');
  const [toast, setToast] = useState('');
  const [posts, setPosts] = useState([]);
  const [shops, setShops] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [hardware, setHardware] = useState([]);
  const [newComment, setNewComment] = useState({});
  const [newPost, setNewPost] = useState({ author: '', role: 'Operator', location: '', content: '' });
  const [turnover, setTurnover] = useState('');
  const [margin, setMargin] = useState('');
  const [operatorMargin, setOperatorMargin] = useState('');
  const [backendStatus, setBackendStatus] = useState(isSupabaseConfigured ? 'connecting' : 'unconfigured');
  const [backendError, setBackendError] = useState('');
  const [adminSession, setAdminSession] = useState(null);
  const [adminAccess, setAdminAccess] = useState('checking');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState('');
  const [adminBusy, setAdminBusy] = useState(false);
  const [formData, setFormData] = useState({
    name: '', phone: '', email: '', address: '', township: '', company: '', product: '', amount: '', rent: '', size: '', openDate: '', photos: [], productPhoto: [], supplierShopId: '',
  });

  const refreshPublicListings = async () => {
    try { const data = await loadOlaData(); if (!data) return; setShops(data.shops); setSuppliers(data.suppliers); setHardware(data.hardware); setPosts(data.posts); setBackendStatus('live'); }
    catch (error) { setBackendStatus('error'); setBackendError(error.message || 'Supabase refresh failed'); }
  };
  useEffect(() => {
    const handlePopState = () => setActiveView(getViewFromPath(window.location.pathname));
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    if (!supabase) { setAdminAccess('unconfigured'); return undefined; }
    let active = true;
    const authorize = async (session) => {
      if (!active) return;
      setAdminSession(session);
      if (!session) { setAdminAccess('signed-out'); return; }
      setAdminAccess('checking');
      const { data, error } = await supabase.from('ola_admins').select('user_id').eq('user_id', session.user.id).maybeSingle();
      if (!active) return;
      if (error || !data) {
        await supabase.auth.signOut();
        setAdminSession(null);
        setAdminAccess(error ? 'error' : 'denied');
        setAdminError(error ? 'Admin access could not be verified. Check the OLA admin migration and RLS setup.' : 'This account is not on the OLA admin allowlist.');
        return;
      }
      setAdminAccess('authorized');
      setAdminError('');
    };
    supabase.auth.getSession().then(({ data, error }) => {
      if (error) { setAdminAccess('error'); setAdminError('Could not restore your sign-in session.'); return; }
      authorize(data.session);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      window.setTimeout(() => { if (active) authorize(session); }, 0);
    });
    return () => { active = false; listener.subscription.unsubscribe(); };
  }, []);
  const adminSignIn = async (event) => {
    event.preventDefault();
    if (!supabase) return;
    setAdminBusy(true); setAdminError('');
    const { data, error } = await supabase.auth.signInWithPassword({ email: adminEmail.trim(), password: adminPassword });
    if (error) { setAdminError('Sign-in failed. Check your email and password.'); setAdminBusy(false); return; }
    const { data: membership, error: membershipError } = await supabase.from('ola_admins').select('user_id').eq('user_id', data.user.id).maybeSingle();
    if (membershipError || !membership) {
      await supabase.auth.signOut();
      setAdminSession(null); setAdminAccess(membershipError ? 'error' : 'denied');
      setAdminError(membershipError ? 'Admin access could not be verified. Check the OLA admin migration and RLS setup.' : 'This account is not on the OLA admin allowlist.');
    } else {
      setAdminSession(data.session);
      setAdminAccess('authorized');
      setAdminPassword('');
      setAdminError('');
    }
    setAdminBusy(false);
  };
  const adminSignOut = async () => {
    if (supabase) await supabase.auth.signOut();
    setAdminSession(null); setAdminAccess('signed-out'); setAdminPassword('');
    openView('overview');
  };
  useEffect(() => {
    let active = true;
    if (!isSupabaseConfigured) { setBackendStatus('unconfigured'); setBackendError('Connect the correct OLA Supabase project and its browser-safe key.'); return undefined; }
    loadOlaData().then((data) => {
      if (!active || !data) return;
      setShops(data.shops);
      setSuppliers(data.suppliers);
      setHardware(data.hardware);
      setPosts(data.posts);
      setBackendStatus('live');
    }).catch((error) => {
      if (!active) return;
      setBackendStatus('error');
      setBackendError(error.message || 'Supabase connection failed');
    });
    return () => { active = false; };
  }, []);

  const split = useMemo(() => {
    const total = Number(turnover) || 0;
    const platform = total * ((Number(margin) || 0) / 100);
    const operatorRate = Number(operatorMargin) || 0;
    const valid = (Number(margin) || 0) + operatorRate <= 100;
    const operator = valid ? total * (operatorRate / 100) : 0;
    const supplier = valid ? Math.max(total - platform - operator, 0) : 0;
    return { total, platform: valid ? platform : 0, operator, supplier, valid };
  }, [turnover, margin, operatorMargin]);

  const openView = (view) => {
    setActiveView(view);
    setMobileMenu(false);
    window.history.pushState({}, '', view === 'overview' ? '/' : `/${view}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const notify = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 4800);
  };

  const updateForm = (key, value) => setFormData((current) => ({ ...current, [key]: value }));

  const submitRole = async (event) => {
    event.preventDefault();
    const identifier = formData.name || formData.company || 'there';
    try {
      if (!supabase) throw new Error('Connect the correct OLA Supabase project before submitting.');
      if (activeRole === 'landlord') {
        const uploadedPhotos = [];
        for (const photo of formData.photos || []) {
          if (!photo.file) continue;
          const uploaded = await uploadOlaImage(photo.file, 'shops');
          if (uploaded) uploadedPhotos.push(uploaded);
        }
        const { error } = await supabase.from('join_applications').insert({
          role: 'landlord',
          status: 'new',
          name: formData.name.trim(),
          email: formData.email || null,
          phone: formData.phone || null,
          township: formData.township || null,
          shop_address: formData.address.trim(),
          approx_size: formData.size.trim() || null,
          expected_rent: formData.rent === '' ? null : Number(formData.rent),
          expected_opening: formData.openDate || null,
          photo_paths: uploadedPhotos.map((photo) => photo.path),
        });
        if (error) throw error;
        const emailSent = await sendRegistrationNotification({
          role: 'landlord',
          name: formData.name.trim(),
          phone: formData.phone || '',
          location: formData.township || '',
          details: {
            email: formData.email || '',
            shopAddress: formData.address.trim(),
            approximateSize: formData.size.trim(),
            expectedRent: formData.rent === '' ? '' : `R${Number(formData.rent).toLocaleString('en-ZA')}`,
            expectedOpening: formData.openDate || '',
          },
        });
        notify(emailSent
          ? `Thanks, ${identifier}. Your shop application was saved privately for review.`
          : `Thanks, ${identifier}. Your application was saved, but the email alert could not be sent.`);
      }
      if (activeRole === 'supplier') {
        if (!formData.productPhoto?.length) {
          notify('Please add at least one clear product photo before submitting.');
          return;
        }
        const targetShop = shops.find((shop) => shop.databaseId === formData.supplierShopId || shop.id === formData.supplierShopId);
        const photo = formData.productPhoto[0];
        const uploaded = photo?.file ? await uploadOlaImage(photo.file, 'products') : null;
        const { error } = await supabase.from('join_applications').insert({
          role: 'supplier',
          status: 'new',
          name: formData.name.trim(),
          email: formData.email || null,
          phone: formData.phone || null,
          township: formData.township || null,
          company: formData.company.trim(),
          product: formData.product.trim(),
          photo_paths: uploaded ? [uploaded.path] : [],
          shop_id: targetShop?.databaseId || null,
        });
        if (error) throw error;
        const emailSent = await sendRegistrationNotification({
          role: 'supplier',
          name: formData.name.trim(),
          phone: formData.phone || '',
          location: formData.township || '',
          details: {
            email: formData.email || '',
            company: formData.company.trim(),
            product: formData.product.trim(),
            interestedShop: targetShop?.name || targetShop?.code || (targetShop ? String(targetShop.id) : ''),
          },
        });
        notify(emailSent
          ? `Thanks, ${identifier}. Your product-supplier application and photo were saved privately for review.`
          : `Thanks, ${identifier}. Your application was saved, but the email alert could not be sent.`);
      }
      if (activeRole === 'investor') {
        const amount = formData.amount === '' ? null : Number(formData.amount);
        const { error } = await supabase.from('join_applications').insert({ role: 'investor', status: 'new', name: identifier, email: formData.email || null, township: formData.township || null, pledge_amount: amount });
        if (error) throw error;
        const emailSent = await sendRegistrationNotification({
          role: 'investor',
          name: identifier,
          phone: formData.phone || '',
          location: formData.township || '',
          details: {
            email: formData.email || '',
            nonBindingPledgeInterest: amount == null ? '' : `R${amount.toLocaleString('en-ZA')}`,
          },
        });
        notify(emailSent
          ? `Thank you, ${identifier}. Your non-binding investor interest was recorded; no payment was taken.`
          : `Thank you, ${identifier}. Your interest was saved, but the email alert could not be sent.`);
      }
      if (activeRole === 'operator') {
        const { error } = await supabase.from('join_applications').insert({ role: 'operator', status: 'new', name: identifier, phone: formData.phone || null, township: formData.township || null, experience: formData.product || null });
        if (error) throw error;
        const emailSent = await sendRegistrationNotification({
          role: 'operator',
          name: identifier,
          phone: formData.phone || '',
          location: formData.township || '',
          details: {
            email: formData.email || '',
            experience: formData.product || '',
          },
        });
        notify(emailSent
          ? `Thanks, ${identifier}. Your operator application was saved for review.`
          : `Thanks, ${identifier}. Your application was saved, but the email alert could not be sent.`);
      }
      setFormData((current) => ({ ...current, name: '', phone: '', email: '', address: '', township: '', company: '', product: '', amount: '', rent: '', size: '', openDate: '', photos: [], productPhoto: [], supplierShopId: '' }));
    } catch (error) {
      setBackendStatus('error');
      setBackendError(error.message || 'Save failed');
      notify('We could not save that submission yet. Check the Supabase policies and try again.');
    }
  };

  const registerHardware = async (item) => {
    try {
      if (!supabase) throw new Error('Connect the correct OLA Supabase project before submitting.');
      if (supabase) {
        const { data, error } = await supabase.from('hardware_assets').insert({ name: item.name, type: item.type, contribution: item.contribution, location: item.location || '', status: 'Pending review', approved: false, is_sample: false });
        if (error) throw error;
      }
      // New assets remain pending review and are shown after the public data feed is refreshed.
      notify(`${item.type} contribution was submitted for review. It is not public until approved.`);
      return true;
    } catch (error) {
      setBackendStatus('error');
      setBackendError(error.message || 'Save failed');
      notify('We could not register that hardware contribution yet.');
      return false;
    }
  };


  const likePost = async (id) => {
    const post = posts.find((item) => item.id === id);
    if (!post) return;
    if (!supabase) { notify('Connect the OLA Supabase backend before engaging with posts.'); return; }
    const { error } = await supabase.rpc('like_post', { p_post_id: id });
    if (error) { notify('We could not save that like.'); return; }
    setPosts((current) => current.map((item) => item.id === id ? { ...item, likes: item.likes + 1 } : item));
  };

  const addComment = async (id) => {
    const text = newComment[id];
    if (!text?.trim()) return;
    if (!supabase) { notify('Connect the OLA Supabase backend before commenting.'); return; }
    const { error } = await supabase.from('community_comments').insert({ post_id: id, author: 'Community member', text: text.trim(), hidden: false });
    if (error) { notify('We could not save that comment yet.'); return; }
    setPosts((current) => current.map((post) => post.id === id ? { ...post, comments: [...post.comments, { author: 'Community member', text: text.trim() }] } : post));
    setNewComment((current) => ({ ...current, [id]: '' }));
    notify('Your comment is now public in the town hall.');
  };

  const addPost = async (event) => {
    event.preventDefault();
    if (!newPost.author.trim() || !newPost.content.trim()) return;
    if (!supabase) { notify('Connect the OLA Supabase backend before posting.'); return; }
    const payload = { author: newPost.author.trim(), role: newPost.role, location: newPost.location.trim() || null, content: newPost.content.trim(), likes: 0, hidden: false, is_sample: false };
    const { error } = await supabase.from('community_posts').insert(payload);
    if (error) { notify('We could not submit that post.'); return; }
    await refreshPublicListings();
    setNewPost({ author: '', role: 'Operator', location: '', content: '' });
    notify('Your post is now public in the town hall.');
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => openView('overview')} aria-label="Go to OLA! overview">
          <span className="brand-mark"><img src="/logo.svg" alt="" /></span>
          <span className="brand-copy"><strong>OLA<span>!</span></strong><small>Ikasi Elethu · by Rovaya Group</small></span>
        </button>
        <nav className={`desktop-nav ${mobileMenu ? 'is-open' : ''}`} aria-label="Primary navigation">
          {navItems.map((item) => <button key={item.id} className={activeView === item.id ? 'active' : ''} onClick={() => openView(item.id)}>{item.label}</button>)}
          {activeView === 'admin' && <button className="active" onClick={() => openView('admin')}>Admin</button>}
        </nav>
        <div className="topbar-actions">
          <a className="network-link" href="https://rovaya.co.za" target="_blank" rel="noreferrer"><Globe2 size={14} /> rovaya.co.za <ArrowUpRight size={13} /></a>
          <span className={`backend-pill ${backendStatus}`} title={backendError || undefined}><span /> {backendStatus === 'live' ? 'Live data connected' : backendStatus === 'connecting' ? 'Connecting' : backendStatus === 'unconfigured' ? 'Backend not connected' : 'Backend unavailable'}</span>
          <button className="button button-small button-dark" onClick={() => { setActiveRole('landlord'); openView('join'); }}>Register a shop <ArrowRight size={15} /></button>
          <button className="menu-button" onClick={() => setMobileMenu((current) => !current)} aria-label="Toggle navigation">{mobileMenu ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>

      {backendStatus !== 'live' && <div className={`connection-banner ${backendStatus}`} role="status">{backendStatus === 'connecting' ? 'Connecting to the configured Supabase project…' : backendStatus === 'unconfigured' ? 'Live data is not connected. Configure the correct OLA Supabase URL and Publishable/anon key to load data and accept submissions.' : 'The configured backend is unavailable or its schema/policies rejected a request. No sample data is being shown.'}</div>}
      {mobileMenu && <div className="mobile-nav-panel">{navItems.map((item) => <button key={item.id} onClick={() => openView(item.id)} className={activeView === item.id ? 'active' : ''}>{item.label}<ChevronRight size={15} /></button>)}</div>}

      <main>
        {activeView === 'admin' && <AdminSection access={adminAccess} session={adminSession} email={adminEmail} setEmail={setAdminEmail} password={adminPassword} setPassword={setAdminPassword} error={adminError} busy={adminBusy} onSignIn={adminSignIn} onSignOut={adminSignOut} onDataChanged={refreshPublicListings} />}
        {activeView === 'overview' && <Overview openView={openView} applyFor={(role) => { setActiveRole(role); openView('join'); }} />}
        {activeView === 'join' && <Join shops={shops} activeRole={activeRole} setActiveRole={setActiveRole} formData={formData} updateForm={updateForm} submitRole={submitRole} backendStatus={backendStatus} />}
        {activeView === 'marketplace' && <Marketplace shops={shops} suppliers={suppliers} hardware={hardware} backendStatus={backendStatus} onSubmitHardware={registerHardware} onRegisterShop={() => { setActiveRole('landlord'); openView('join'); }} />}
        {activeView === 'pilot' && <Pilot shops={shops} suppliers={suppliers} hardware={hardware} posts={posts} backendStatus={backendStatus} onBrowseMarketplace={() => openView('marketplace')} />}
        {activeView === 'calculator' && <CalculatorView turnover={turnover} setTurnover={setTurnover} margin={margin} setMargin={setMargin} operatorMargin={operatorMargin} setOperatorMargin={setOperatorMargin} split={split} />}
        {activeView === 'community' && <Community posts={posts} newPost={newPost} setNewPost={setNewPost} addPost={addPost} likePost={likePost} newComment={newComment} setNewComment={setNewComment} addComment={addComment} backendStatus={backendStatus} />}
      </main>

      <footer className="footer"><div><span className="footer-mark"><img src="/logo.svg" alt="OLA!" /><span>OLA<span>!</span></span></span><span>Built for the people who keep the kasi moving. Ikasi Elethu.</span></div><div className="footer-right"><span>© 2026 Rovaya Group</span><button onClick={() => openView('community')}>Town hall <ArrowUpRight size={14} /></button><button onClick={() => openView('admin')}>Admin sign-in <LockKeyhole size={14} /></button></div></footer>
      {toast && <div className="toast"><CheckCircle2 size={18} /><span>{toast}</span><button onClick={() => setToast('')} aria-label="Dismiss notification"><X size={15} /></button></div>}
    </div>
  );
}

function AdminSection({ access, session, email, setEmail, password, setPassword, error, busy, onSignIn, onSignOut, onDataChanged }) {
  if (access === 'unconfigured') return <section className="section-pad page-section admin-page"><div className="admin-card"><LockKeyhole size={25} /><span className="eyebrow">OLA! ADMIN</span><h1>Admin sign-in is unavailable.</h1><p>Connect the OLA Supabase project before using the admin area.</p></div></section>;
  if (access === 'checking') return <section className="section-pad page-section admin-page"><div className="admin-card" role="status"><LockKeyhole size={25} /><span className="eyebrow">OLA! ADMIN</span><h1>Checking access…</h1><p>Your account must be explicitly approved for administration.</p></div></section>;
  if (access === 'authorized' && session) return <AdminConsole email={session.user.email || email} onSignOut={onSignOut} onDataChanged={onDataChanged} />;
  return <section className="section-pad page-section admin-page"><form className="form-panel admin-card" onSubmit={onSignIn}><span className="admin-lock"><LockKeyhole size={22} /></span><span className="eyebrow">RESTRICTED AREA · OLA!</span><h1>Admin sign-in</h1><p>Sign in with an approved OLA Supabase Auth account.</p>{error && <div className="admin-error" role="alert">{error}</div>}<label className="field"><span>Email address</span><input type="email" autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} required /></label><label className="field"><span>Password</span><input type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required /></label><button className="button button-primary form-submit" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in securely'} <ArrowRight size={16} /></button><p className="form-footnote">Only explicitly authorized OLA admins can view private submissions and enquiries.</p></form></section>;
}
function SectionIntro({ eyebrow, title, body, action }) {
  return <div className="section-intro"><div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div>{body && <p>{body}</p>}{action}</div>;
}

function Overview({ openView, applyFor }) {
  return <>
    <section className="hero section-pad">
      <div className="hero-copy">
        <div className="eyebrow eyebrow-dark"><Sparkles size={14} /> Ikasi Elethu · A platform for the hustle</div>
        <div className="slogan-lockup"><span>IKASI ELETHU</span><small>Our kasi. Our hustle. Our future.</small></div>
        <h1>For the people who make a plan. <em>We’re building the connections.</em></h1>
        <p className="hero-lede">OLA! is being built to connect local shop-space owners, operators, product suppliers and supporters. Live opportunities and activity appear only when verified records are connected.</p>
        <div className="hero-actions"><button className="button button-primary" onClick={() => openView('join')}>Register your interest <ArrowRight size={16} /></button><button className="button button-link" onClick={() => openView('marketplace')}>Browse public listings <ArrowUpRight size={16} /></button></div>
        <div className="hero-proof"><span><Check size={14} /> Applications are reviewed before publication</span><span><Check size={14} /> No payment is taken through this site</span></div>
      </div>
      <div className="hero-visual" aria-label="Illustration of OLA's intended ecosystem">
        <div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" />
        <div className="visual-label"><Activity size={15} /> OLA! concept</div>
        <div className="flow-card">
          <div className="flow-head"><div><span className="mini-label">PLATFORM MODEL</span><strong>Connecting local opportunity</strong></div><span className="pulse-dot" /></div>
          <div className="flow-map"><div className="flow-line line-a" /><div className="flow-line line-b" /><div className="flow-node node-one"><Building2 size={17} /><span>Shop space</span></div><div className="flow-node node-two"><Factory size={17} /><span>Product suppliers</span></div><div className="flow-node node-three"><Store size={17} /><span>Operators</span></div><div className="flow-node node-four"><TrendingUp size={17} /><span>Shared opportunity</span></div></div>
          <div className="flow-bottom"><span>Listings <strong>from live records</strong></span><span>Activity <strong>not yet verified</strong></span></div>
        </div>
        <div className="floating-card floating-card-a"><span className="floating-icon lime"><PackageCheck size={16} /></span><div><strong>Local supply</strong><small>Shown when approved records are available</small></div></div>
        <div className="floating-card floating-card-b"><span className="floating-icon coral"><HeartHandshake size={16} /></span><div><strong>Community-led</strong><small>Apply to take part</small></div></div>
      </div>
    </section>
    <section className="section-pad section-block">
      <SectionIntro eyebrow="A connected network" title="A place to bring an opportunity and find the next step." body="OLA! is intended to help local local shop-space owners, operators, product suppliers and supporters connect. Submitted information stays pending review until approved." />
      <div className="unlock-grid">
        <UnlockCard icon={Building2} number="01" title="List a space" body="Share information about a possible trading location." accent="lime" onClick={() => applyFor('landlord')} />
        <UnlockCard icon={Store} number="02" title="Apply to operate" body="Tell the team about your experience and the area where you would like to operate." accent="coral" onClick={() => applyFor('operator')} />
        <UnlockCard icon={Factory} number="03" title="Apply as a product supplier" body="Submit product details and a photo for review before a catalog listing is shown." accent="sky" onClick={() => applyFor('supplier')} />
        <UnlockCard icon={BadgeDollarSign} number="04" title="Register interest" body="Supporters can leave non-binding interest. This site does not collect or process payments." accent="gold" onClick={() => applyFor('investor')} />
      </div>
    </section>
    <section className="investor-band section-pad">
      <div className="investor-copy"><div className="eyebrow">Planning tool</div><h2>Explore a possible value split.</h2><p>The calculator is only a user-input scenario. It does not represent agreed commercial terms, current sales or a forecast.</p><button className="button button-light" onClick={() => openView('calculator')}>Open the calculator <Calculator size={16} /></button></div>
      <div className="investor-metrics"><div className="metric-large"><span>01</span><strong>Submit</strong><p>Share information for review.</p></div><div className="metric-large"><span>02</span><strong>Review</strong><p>Records must be checked before public display.</p></div><div className="metric-large"><span>03</span><strong>Connect</strong><p>Approved records can support introductions.</p></div></div>
    </section>
    <section className="section-pad section-block closing-block"><div><div className="eyebrow">Build with us</div><h2>Bring a shop space, products, skills or an idea.</h2><p>Register your interest and the team can follow up after the application backend is connected.</p></div><div className="closing-actions"><button className="button button-primary" onClick={() => openView('join')}>Register your interest <ArrowRight size={16} /></button><button className="button button-link" onClick={() => openView('community')}>Open town hall <MessageCircle size={16} /></button></div></section>
  </>;
}

function UnlockCard({ icon: Icon, number, title, body, accent, onClick }) {
  return <button type="button" className={`unlock-card accent-${accent}`} onClick={onClick}><div className="card-top"><span className="number">{number}</span><span className="card-icon"><Icon size={20} /></span></div><h3>{title}</h3><p>{body}</p><span className="card-arrow"><ArrowUpRight size={17} /></span></button>;
}

function Join({ shops, activeRole, setActiveRole, formData, updateForm, submitRole, backendStatus }) {
  const selected = roles.find((role) => role.id === activeRole);
  const selectedShop = activeRole === 'supplier' ? shops.find((shop) => shop.databaseId === formData.supplierShopId || shop.id === formData.supplierShopId) : null;
  return <section className="section-pad page-section"><SectionIntro eyebrow="Join the hustle" title="Choose your move." body="Tell us what you can bring and where you want to make a move." /><div className="role-layout"><div className="role-list">{roles.map((role) => { const Icon = role.icon; return <button key={role.id} className={`role-card ${activeRole === role.id ? 'selected' : ''} role-${role.accent}`} onClick={() => setActiveRole(role.id)}><span className="role-icon"><Icon size={20} /></span><span className="role-text"><strong>{role.label}</strong><small>{role.detail}</small></span><ChevronRight size={18} /></button>; })}<div className="role-note"><ShieldCheck size={18} /><div><strong>Made for people who make a plan</strong><span>No pitch deck. Tell us what you can bring to the kasi.</span></div></div></div>
    <form className="form-panel" onSubmit={submitRole}><div className="form-panel-head"><span className={`form-badge ${selected.accent}`}>{React.createElement(selected.icon, { size: 16 })}</span><div><span className="mini-label">YOUR ROLE</span><h3>{selected.label}</h3></div><span className="step-counter">01 <span>/ 01</span></span></div><div className="form-grid">
      {activeRole === 'investor' ? <><Field label="Your name" value={formData.name} onChange={(value) => updateForm('name', value)} placeholder="e.g. Lerato M." required /><Field label="Email address" type="email" value={formData.email} onChange={(value) => updateForm('email', value)} placeholder="you@company.com" required /><Field label="Indicative interest amount (not a payment)" type="number" value={formData.amount} onChange={(value) => updateForm('amount', value)} prefix="R" min="0" step="500" /><Field label="Where should we focus?" value={formData.township} onChange={(value) => updateForm('township', value)} placeholder="Any high-demand node" /></> : activeRole === 'supplier' ? <><Field label="Supplier business / brand" value={formData.company} onChange={(value) => updateForm('company', value)} placeholder="Your business or co-op" required /><Field label="Contact person" value={formData.name} onChange={(value) => updateForm('name', value)} placeholder="Full name" required /><Field label="Products supplied" value={formData.product} onChange={(value) => updateForm('product', value)} placeholder="Bread, sauces, cleaning products…" required /><Field label="Delivery radius" value={formData.township} onChange={(value) => updateForm('township', value)} placeholder="e.g. 10km around Soweto" /><label className="field"><span>Shop to supply</span><div className="input-wrap select-wrap"><select value={formData.supplierShopId} onChange={(event) => updateForm('supplierShopId', event.target.value)}><option value="">Open to matching</option>{shops.map((shop) => <option key={shop.databaseId || shop.id} value={shop.databaseId || shop.id}>{shop.address} · {shop.city}</option>)}</select></div></label><Field label="Product photo" type="file" onChange={(value) => updateForm('productPhoto', value)} accept="image/jpeg,image/png,image/webp" required wide /><p className="form-help wide">Approved product photos appear in the public supplier directory.</p>{selectedShop && <div className="supplier-shop-preview wide"><div className="supplier-shop-preview-head"><div><span className="mini-label">YOUR SELECTED SHOP</span><strong>{selectedShop.address}</strong><small>{selectedShop.city} · {selectedShop.id}</small></div><span>{selectedShop.photoGallery?.length || 0} shop photo(s)</span></div>{selectedShop.photoGallery?.length ? <div className="supplier-shop-preview-photos">{selectedShop.photoGallery.map((src, index) => <a href={src} key={`${src}-${index}`} target="_blank" rel="noreferrer"><img src={src} alt={`${selectedShop.address}, shop photo ${index + 1}`} loading="lazy" /></a>)}</div> : <p>This approved shop has no photos on file yet. Browse the marketplace for other spaces with photos.</p>}</div>}</> : activeRole === 'operator' ? <><Field label="Your name" value={formData.name} onChange={(value) => updateForm('name', value)} placeholder="Full name" required /><Field label="Mobile number" value={formData.phone} onChange={(value) => updateForm('phone', value)} placeholder="+27 …" required /><Field label="Preferred township" value={formData.township} onChange={(value) => updateForm('township', value)} placeholder="Where would you operate?" required /><Field label="Relevant experience" value={formData.product} onChange={(value) => updateForm('product', value)} placeholder="Retail, stock, hospitality…" /></> : <><Field label="Your name" value={formData.name} onChange={(value) => updateForm('name', value)} placeholder="Full name" required /><Field label="Mobile number" value={formData.phone} onChange={(value) => updateForm('phone', value)} placeholder="+27 …" required /><Field label="Shop address" value={formData.address} onChange={(value) => updateForm('address', value)} placeholder="Street, suburb or landmark" required wide /><Field label="Township / area" value={formData.township} onChange={(value) => updateForm('township', value)} placeholder="e.g. Orlando West" /><Field label="Expected opening date" type="date" value={formData.openDate} onChange={(value) => updateForm('openDate', value)} required /><Field label="Expected monthly rent" type="number" value={formData.rent} onChange={(value) => updateForm('rent', value)} placeholder="e.g. 6500" prefix="R" /><Field label="Approximate size" value={formData.size} onChange={(value) => updateForm('size', value)} placeholder="e.g. 28m²" /><Field label="Shop photo pack" type="file" onChange={(value) => updateForm('photos', value)} accept="image/jpeg,image/png,image/webp" multiple wide /></>}
    </div><label className="checkbox-row"><input type="checkbox" required /><span>Keep me in the loop about OLA! updates and next steps.</span></label><button className="button button-primary form-submit" type="submit">Send my details <ArrowRight size={16} /></button><p className="form-footnote">{activeRole === 'supplier' ? 'Required · Add at least one clear product photo. Submissions stay private until approval.' : backendStatus === 'live' ? 'Applications and uploaded photos are saved to the connected OLA Supabase project for review.' : 'Connect the OLA Supabase backend before submitting; no local-only save is performed.'}</p></form></div></section>;
}

function Field({ label, value, onChange, placeholder, type = 'text', prefix, wide, ...props }) {
  return <label className={`field ${wide ? 'wide' : ''}`}><span>{label}</span><div className="input-wrap">{prefix && <b>{prefix}</b>}<input type={type} {...(type === 'file' ? {} : { value })} onChange={(event) => onChange(type === 'file' ? Array.from(event.target.files || []).map((file) => ({ name: file.name, file, url: URL.createObjectURL(file) })) : event.target.value)} placeholder={placeholder} {...props} /></div></label>;
}

function Marketplace({ shops, suppliers, hardware, backendStatus, onSubmitHardware, onRegisterShop }) {
  const [selectedShopId, setSelectedShopId] = useState(null);
  const [query, setQuery] = useState('');
  const [area, setArea] = useState('All areas');
  const [hardwareForm, setHardwareForm] = useState({ name: '', type: 'Display fridge', contribution: '', location: '' });
  const ready = backendStatus === 'live';
  const selectedShop = shops.find((shop) => shop.id === selectedShopId);
  const areas = ['All areas', ...new Set(shops.map((shop) => (shop.city || '').split(',')[0]).filter(Boolean))];
  const filteredShops = shops.filter((shop) => `${shop.address || ''} ${shop.city || ''} ${(shop.tags || []).join(' ')}`.toLowerCase().includes(query.toLowerCase()) && (area === 'All areas' || (shop.city || '').startsWith(area)));
  const submitHardware = async (event) => { event.preventDefault(); if (!hardwareForm.name.trim() || !hardwareForm.contribution.trim()) return; if (await onSubmitHardware({ ...hardwareForm })) setHardwareForm({ name: '', type: 'Display fridge', contribution: '', location: '' }); };
  if (selectedShop) return <section className="section-pad page-section marketplace-page"><button className="back-link" onClick={() => setSelectedShopId(null)}><ArrowRight size={15} className="back-arrow" /> Back to marketplace</button><div className="shop-detail-head"><div><div className="eyebrow">Approved public listing · {selectedShop.id}</div><h2>{selectedShop.address}</h2><p><MapPinned size={15} /> {selectedShop.city}</p></div><span className="listing-status"><span /> {selectedShop.status || 'Approved'}</span></div><div className="shop-detail-layout"><div className="shop-detail-gallery"><PhotoMosaic shop={selectedShop} /><div className="gallery-caption"><Camera size={15} /><span>{selectedShop.photoGallery?.length ? `${selectedShop.photoGallery.length} real shop photo(s) · visible to product suppliers` : 'No listing photos provided'}</span></div></div><aside className="shop-detail-aside"><div className="detail-facts"><div><span>Expected monthly rent</span><strong>{selectedShop.rent == null ? 'Not provided' : money(selectedShop.rent)}</strong></div><div><span>Shop size</span><strong>{selectedShop.size || 'Not provided'}</strong></div><div><span>Trading hours</span><strong>{selectedShop.hours || 'Not provided'}</strong></div><div><span>Expected opening</span><strong>{selectedShop.openDate || 'Not provided'}</strong></div></div><div className="detail-owner"><span className="mini-label">CONTACT</span><strong>Contact details are not shown publicly.</strong><span>Contact details are not published by this app.</span></div><button className="button button-primary full-width" onClick={onRegisterShop}>Submit another space <ArrowRight size={16} /></button></aside></div><div className="shop-detail-bottom"><div className="detail-story"><span className="mini-label">LISTING DETAILS</span><h3>Information provided by the submitter</h3><p>{selectedShop.description || 'No description provided.'}</p><div className="tag-row">{(selectedShop.tags || []).map((tag) => <span key={tag}>{tag}</span>)}</div></div><div className="supplier-progress-card"><div className="supplier-progress-head"><div><span className="mini-label">SUPPLIER COMMITMENTS</span><h3>{selectedShop.suppliersSigned == null ? 'Not reported' : `${selectedShop.suppliersSigned} reported`}</h3></div><PackageCheck size={22} /></div><p>Commitment counts are shown only when provided in the approved listing data.</p></div><div className="hardware-needs-card"><div className="supplier-progress-head"><div><span className="mini-label">HARDWARE NEEDS</span><h3>Information on file</h3></div><Hammer size={21} /></div><div className="need-list">{selectedShop.hardwareNeeds?.length ? selectedShop.hardwareNeeds.map((need) => <span key={need}><Plus size={13} /> {need}</span>) : <span>No hardware needs provided.</span>}</div></div></div></section>;
  return <section className="section-pad page-section marketplace-page"><SectionIntro eyebrow="OLA! marketplace" title="See real shop spaces before you supply." body="Product suppliers can inspect approved tuckshop locations and their uploaded photos before choosing where to supply. Only verified public listings are shown." action={<button className="button button-primary" onClick={onRegisterShop}>Submit a shop for review <Plus size={16} /></button>} /><div className="marketplace-kpis"><div><span className="marketplace-kpi-value">{ready ? shops.length : '—'}</span><span>approved public shops</span></div><div><span className="marketplace-kpi-value">{ready ? suppliers.length : '—'}</span><span>approved product suppliers</span></div></div><div className="marketplace-toolbar"><div className="market-search"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by suburb, address or tag" /></div><div className="market-filter"><SlidersHorizontal size={15} /><select value={area} onChange={(event) => setArea(event.target.value)}>{areas.map((item) => <option key={item}>{item}</option>)}</select></div><span className="result-count">{ready ? `${filteredShops.length} matches` : 'Data unavailable'}</span></div>{!ready ? <div className="empty-market"><Search size={25} /><h3>Marketplace data is unavailable.</h3><p>Connect the OLA Supabase project and load its approved listings. No example listings are shown.</p></div> : filteredShops.length ? <div className="shop-market-grid">{filteredShops.map((shop) => <ShopCard key={shop.id} shop={shop} onOpen={() => setSelectedShopId(shop.id)} />)}</div> : <div className="empty-market"><Search size={25} /><h3>{query || area !== 'All areas' ? 'No approved listings match those filters.' : 'No approved shop listings yet.'}</h3><p>{query || area !== 'All areas' ? 'Try another search.' : 'Submitted spaces remain private until approved.'}</p></div>}
    <section className="supplier-catalog"><div className="table-head"><div><span className="mini-label">PRODUCT SUPPLIERS</span><h3>Approved supplier directory</h3></div><span className="table-count">{ready ? `${suppliers.length} records` : '—'}</span></div>{ready && suppliers.length ? <div className="supplier-catalog-grid">{suppliers.map((supplier) => <SupplierCatalogCard key={supplier.id} supplier={supplier} shops={shops} />)}</div> : <p className="empty-note">{ready ? 'No approved product suppliers yet.' : 'Supplier listings appear when the connected database is available.'}</p>}</section>
    <div className="hardware-marketplace"><div className="hardware-copy"><div className="eyebrow">Hardware submissions</div><h2>Register an asset for review.</h2><p>Unapproved hardware contributions remain private until a reviewer approves them.</p><div className="hardware-examples"><span><Monitor size={15} /> Till points</span><span><Boxes size={15} /> Shelving</span><span><ReceiptText size={15} /> POS kits</span><span><DoorOpen size={15} /> Fixtures</span></div></div><form className="hardware-form" onSubmit={submitHardware}><div className="form-panel-head"><span className="form-badge lime"><Hammer size={16} /></span><div><span className="mini-label">SUBMIT AN ASSET</span><h3>Share a contribution</h3></div></div><div className="hardware-form-grid"><label className="field"><span>Your name / business</span><input value={hardwareForm.name} onChange={(event) => setHardwareForm({ ...hardwareForm, name: event.target.value })} required /></label><label className="field"><span>Asset type</span><select value={hardwareForm.type} onChange={(event) => setHardwareForm({ ...hardwareForm, type: event.target.value })}><option>Display fridge</option><option>Chest freezer</option><option>Till point</option><option>Shelving</option><option>Other fit-out</option></select></label><label className="field wide"><span>What can you contribute?</span><input value={hardwareForm.contribution} onChange={(event) => setHardwareForm({ ...hardwareForm, contribution: event.target.value })} required /></label><label className="field"><span>Where is it located?</span><input value={hardwareForm.location} onChange={(event) => setHardwareForm({ ...hardwareForm, location: event.target.value })} /></label></div><button className="button button-primary form-submit" type="submit">Submit for review <ArrowRight size={16} /></button><p className="form-footnote">Submission requires the connected OLA Supabase backend and remains private until approved.</p></form></div>
    <div className="hardware-roster"><div className="table-head"><div><span className="mini-label">APPROVED ASSETS</span><h3>Public hardware roster</h3></div><span className="table-count">{ready ? `${hardware.length} records` : '—'}</span></div>{!ready ? <p className="empty-note">Hardware data is unavailable until the live backend is connected.</p> : hardware.length ? <div className="hardware-roster-grid">{hardware.map((item) => <div className="hardware-roster-item" key={item.id}><span className="row-icon coral"><Hammer size={15} /></span><div><strong>{item.contribution}</strong><span>{item.name}{item.location ? ` · ${item.location}` : ''}</span></div><small>{item.status}</small></div>)}</div> : <p className="empty-note">No approved hardware assets yet.</p>}</div>
  </section>;
}

function ShopCard({ shop, onOpen }) {
  const canShowSupplierProgress = shop.suppliersSigned != null && shop.supplierTarget != null && shop.supplierTarget > 0;
  const supplierPercent = canShowSupplierProgress ? Math.round((shop.suppliersSigned / shop.supplierTarget) * 100) : null;
  return <article className="shop-card"><PhotoMosaic shop={shop} compact /><div className="shop-card-body"><div className="shop-card-top"><div><span className="shop-id">{shop.id || 'Approved listing'}</span><h3>{shop.address}</h3><p><MapPin size={12} /> {shop.city || 'Location not provided'}</p></div><span className="shop-status-dot"><span /></span></div><div className="shop-card-facts"><span><strong>{shop.rent == null ? 'Not provided' : money(shop.rent)}</strong><small>expected rent</small></span><span><strong>{shop.size || 'Not provided'}</strong><small>shop size</small></span><span><strong>{shop.photoGallery?.length || 0}</strong><small>shop photos</small></span></div><div className="shop-open-line"><Landmark size={13} /> Expected opening: <strong>{shop.openDate || 'Not provided'}</strong></div>{canShowSupplierProgress && <div className="shop-supplier-bar"><div><span>Supplier commitments</span><strong>{supplierPercent}%</strong></div><div className="progress light-progress"><span style={{ width: `${supplierPercent}%` }} /></div></div>}<div className="shop-card-footer"><span><Camera size={13} /> Actual shop photos for suppliers</span><button onClick={onOpen}>Open listing <ArrowUpRight size={14} /></button></div></div></article>;
}

function PhotoMosaic({ shop, compact = false }) {
  const photos = (shop.photoGallery || []).filter(Boolean);
  const labels = shop.photoViews || [];
  if (!photos.length) return <div className={`photo-mosaic ${compact ? 'compact' : ''} empty-photo-mosaic`}><div className="photo-tile empty-photo-tile"><Image size={compact ? 15 : 20} /><span>No shop photo provided</span><small>Check other approved listings with photos</small></div></div>;
  return <div className={`photo-mosaic ${compact ? 'compact' : ''} ${photos.length === 1 ? 'single-photo' : ''}`}>{photos.map((url, index) => <a className="photo-tile" href={url} target="_blank" rel="noreferrer" title="Open full-size shop photo" key={`${url}-${index}`}><img src={url} alt={`${shop.address || 'Shop'} photo ${index + 1}${shop.city ? `, ${shop.city}` : ''}`} loading="lazy" /><span>{labels[index] || `Shop photo ${index + 1}`}</span><small>Open full-size photo</small></a>)}</div>;
}

function SupplierCatalogCard({ supplier, shops }) {
  const linkedShop = shops.find((shop) => shop.databaseId === supplier.shopId);
  return <article className="supplier-product-card">{supplier.photoGallery?.length ? <a className="supplier-product-image" href={supplier.photoGallery[0]} target="_blank" rel="noreferrer"><img src={supplier.photoGallery[0]} alt={`${supplier.product} from ${supplier.company}`} loading="lazy" /></a> : <div className="supplier-product-image no-product-photo"><PackageCheck size={22} /><span>Product photo not available</span></div>}<div className="supplier-product-copy"><span className="mini-label">{supplier.category || 'PRODUCT SUPPLIER'}</span><h4>{supplier.product}</h4><p>{supplier.company}</p><div className="supplier-product-meta">{supplier.price == null ? <span>Price on request</span> : <span>From {money(supplier.price)}</span>}{supplier.photoGallery?.length > 1 && <span>{supplier.photoGallery.length} photos</span>}</div>{linkedShop && <small className="supplier-linked-shop">Linked shop · {linkedShop.address}, {linkedShop.city}</small>}</div></article>;
}

function Pilot({ shops, suppliers, hardware, posts, backendStatus, onBrowseMarketplace }) {
  const ready = backendStatus === 'live';
  const count = (items) => ready ? items.length : '—';
  return <section className="section-pad page-section">
    <SectionIntro eyebrow="Pilot dashboard" title="Verified activity from the connected database." body="Only records returned by the live OLA data connection appear here. No sample activity or estimated totals are shown." action={<div className="pilot-actions"><span className={`live-tag ${ready ? '' : 'not-live'}`}><span /> {ready ? 'Connected data' : backendStatus === 'connecting' ? 'Loading data' : 'Data unavailable'}</span><button className="button button-small button-dark" onClick={onBrowseMarketplace}>Browse listings <ArrowUpRight size={14} /></button></div>} />
    {!ready && <div className="empty-market"><Activity size={25} /><h3>Live pilot data is not available.</h3><p>Connect the OLA Supabase project and make sure its required tables and read policies are in place. No demo records are substituted.</p></div>}
    <div className="pilot-top-grid"><div className="pilot-scorecard"><div className="score-head"><div><span className="mini-label">PUBLIC ACTIVITY</span><strong>{ready ? 'Live records' : '—'}</strong></div><Activity size={22} /></div><p className="score-note"><ShieldCheck size={14} /> This dashboard does not count pledges, payments, sales or active users.</p></div><div className="pilot-snapshot"><div className="mini-label">DATABASE COUNTS</div><div className="snapshot-grid"><Snapshot label="Public shops" value={count(shops)} icon={Building2} /><Snapshot label="Approved suppliers" value={count(suppliers)} icon={Boxes} /><Snapshot label="Approved assets" value={count(hardware)} icon={Hammer} /><Snapshot label="Community posts" value={count(posts)} icon={MessageCircle} /></div><div className="snapshot-caption"><Activity size={15} /><span>{ready ? 'Counts reflect currently returned public records.' : 'Counts appear after the backend loads successfully.'}</span></div></div></div>
    {ready && <div className="pilot-tables"><div className="table-card"><div className="table-head"><div><span className="mini-label">PUBLIC SPACES</span><h3>Approved shop listings</h3></div><span className="table-count">{shops.length} records</span></div><div className="table-list">{shops.length ? shops.map((shop) => <div className="table-row" key={shop.id}><div className="row-icon lime"><Building2 size={16} /></div><div className="row-main"><strong>{shop.address}</strong><span><MapPin size={12} /> {shop.city} · {shop.size || 'Size not provided'}</span></div><div className="row-status"><span>{shop.status || 'Approved'}</span></div></div>) : <p className="empty-note">No public shop records yet.</p>}</div></div><div className="table-card"><div className="table-head"><div><span className="mini-label">PUBLIC CATALOG</span><h3>Approved suppliers</h3></div><span className="table-count">{suppliers.length} records</span></div><div className="table-list">{suppliers.length ? suppliers.map((supplier) => <div className="table-row" key={supplier.id}><div className="row-icon coral"><PackageCheck size={16} /></div><div className="row-main"><strong>{supplier.product}</strong><span>{supplier.company}{supplier.category ? ` · ${supplier.category}` : ''}</span></div><div className="price-tag">{supplier.price == null ? 'Price not provided' : `from ${money(supplier.price)}`}</div></div>) : <p className="empty-note">No approved supplier records yet.</p>}</div></div></div>}
  </section>;
}

function Snapshot({ label, value, icon: Icon }) { return <div className="snapshot-item"><Icon size={16} /><strong>{value}</strong><span>{label}</span></div>; }

function CalculatorView({ turnover, setTurnover, margin, setMargin, operatorMargin, setOperatorMargin, split }) {
  const entered = turnover !== '' && Number(turnover) > 0;
  const share = (amount) => entered && split.valid ? `${Math.round((amount / split.total) * 100)}%` : '0%';
  return <section className="section-pad page-section calculator-page"><SectionIntro eyebrow="Scenario calculator" title="Model a split using your own assumptions." body="This tool is illustrative only. It uses only values you enter; no OLA! terms, sales, or forecast are prefilled." /><div className="calculator-layout"><div className="calculator-inputs"><div className="input-card"><div className="card-topline"><span className="number">01</span><span className="mini-label">MONTHLY SALES ASSUMPTION</span></div><div className="big-input"><span>R</span><input type="number" value={turnover} onChange={(event) => setTurnover(event.target.value)} min="0" step="1000" placeholder="Enter amount" /></div></div><div className="input-card"><div className="card-topline"><span className="number">02</span><span className="mini-label">OLA! SHARE ASSUMPTION</span></div><div className="big-input"><input type="number" value={margin} onChange={(event) => setMargin(event.target.value)} min="0" max="100" step="1" placeholder="%" /><span>%</span></div></div><div className="input-card"><div className="card-topline"><span className="number">03</span><span className="mini-label">OPERATOR SHARE ASSUMPTION</span></div><div className="big-input"><input type="number" value={operatorMargin} onChange={(event) => setOperatorMargin(event.target.value)} min="0" max="100" step="1" placeholder="%" /><span>%</span></div></div><div className="calculator-note"><ShieldCheck size={17} /><p><strong>Not commercial advice.</strong> The shares are user-entered examples, not agreed rates. The supplier share is the remainder only when total entered shares are at most 100%.</p></div></div><div className="split-card"><div className="split-card-head"><div><span className="mini-label">ILLUSTRATIVE MONTHLY SPLIT</span><h3>{entered ? `${money(split.total)} scenario` : 'Enter a sales assumption'}</h3></div><CircleDollarSign size={24} /></div>{!split.valid && <p className="empty-note">The entered shares exceed 100%. Adjust the assumptions to view a split.</p>}<div className="split-bar"><span className="supplier-segment" style={{ width: share(split.supplier) }} /><span className="operator-segment" style={{ width: share(split.operator) }} /><span className="platform-segment" style={{ width: share(split.platform) }} /></div><div className="split-legend"><Legend color="supplier-dot" label="Supplier remainder" value={split.supplier} percent={share(split.supplier)} /><Legend color="operator-dot" label="Operator assumption" value={split.operator} percent={share(split.operator)} /><Legend color="platform-dot" label="OLA! assumption" value={split.platform} percent={share(split.platform)} /></div><div className="split-insight"><TrendingUp size={18} /><div><strong>Scenario only</strong><span>Actual terms require separate agreement.</span></div><ArrowUpRight size={18} /></div></div></div></section>;
}

function Legend({ color, label, value, percent }) { return <div className="legend-row"><span className={`legend-dot ${color}`} /><span>{label}</span><strong>{money(value)}</strong><small>{percent}</small></div>; }

function Community({ posts, newPost, setNewPost, addPost, likePost, newComment, setNewComment, addComment, backendStatus }) {
  const ready = backendStatus === 'live';
  return <section className="section-pad page-section community-page"><SectionIntro eyebrow="Town hall" title="A place for the community to connect." body="Posts and replies shown here come from the connected OLA database. New contributions require the backend to be available." action={<span className="online-count"><span /> {ready ? `${posts.length} posts loaded` : 'Feed not connected'}</span>} /><div className="community-layout"><form className="composer" onSubmit={addPost}><div className="composer-head"><span className="avatar avatar-lime">YOU</span><div><strong>Start a conversation</strong><span>Ask, offer, connect.</span></div></div><input value={newPost.author} onChange={(event) => setNewPost({ ...newPost, author: event.target.value })} placeholder="Your name" required /><textarea value={newPost.content} onChange={(event) => setNewPost({ ...newPost, content: event.target.value })} placeholder="What would you like to share?" rows="4" required /><div className="composer-footer"><div className="composer-fields"><input value={newPost.location} onChange={(event) => setNewPost({ ...newPost, location: event.target.value })} placeholder="Location (optional)" /><select value={newPost.role} onChange={(event) => setNewPost({ ...newPost, role: event.target.value })}><option>Operator</option><option>Landlord</option><option>Local supplier</option><option>Investor</option></select></div><button className="button button-dark" type="submit">Post to town hall <Send size={15} /></button></div><p className="form-footnote">Town hall posts are public as soon as you share them; no admin approval is required.</p></form><div className="post-feed">{!ready ? <div className="empty-market"><MessageCircle size={25} /><h3>Community feed unavailable.</h3><p>Connect the OLA Supabase backend to load posts. Sample posts are not shown.</p></div> : posts.length ? posts.map((post) => <article className="post-card" key={post.id}><div className="post-head"><span className={`avatar ${post.role.toLowerCase().includes('supplier') ? 'avatar-coral' : post.role.toLowerCase().includes('landlord') ? 'avatar-sky' : 'avatar-lime'}`}>{post.author.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><div className="post-author"><strong>{post.author}</strong><span>{post.role}{post.location ? ` · ${post.location}` : ''}</span></div><time>{post.timestamp}</time></div><p className="post-content">{post.content}</p><div className="post-actions"><button onClick={() => likePost(post.id)}><ThumbsUp size={15} /> {post.likes}</button><span><MessageCircle size={15} /> {post.comments.length} comments</span></div>{post.comments.length > 0 && <div className="comments">{post.comments.map((comment, index) => <div className="comment" key={`${post.id}-${index}`}><span className="comment-dot" /><p><strong>{comment.author}</strong> {comment.text}</p></div>)}</div>}<div className="comment-input"><input value={newComment[post.id] || ''} onChange={(event) => setNewComment((current) => ({ ...current, [post.id]: event.target.value }))} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); addComment(post.id); } }} placeholder="Add a comment…" /><button onClick={() => addComment(post.id)} aria-label="Add comment"><ArrowUpRight size={16} /></button></div></article>) : <div className="empty-market"><MessageCircle size={25} /><h3>No posts yet.</h3><p>Public town hall contributions will appear here after the live database loads.</p></div>}</div></div></section>;
}

createRoot(document.getElementById('root')).render(<App />);
