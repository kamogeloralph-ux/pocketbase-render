import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Check, ChevronDown, ClipboardList, Database, Edit3, Eye, LoaderCircle, LogOut, Plus, RefreshCw, Search, ShieldAlert, Trash2, X } from 'lucide-react';
import { publicOlaImageUrl, supabase } from '../lib/supabase';

const resources = [
  {
    table: 'join_applications', label: 'Applications', description: 'Private submissions and contact details. Approving a landlord or product supplier publishes its public listing.', order: 'created_at',
    fields: [
      f('role', 'Application type', 'select', { options: ['landlord', 'operator', 'supplier', 'investor'], required: true }),
      f('name', 'Contact name', 'text', { required: true }), f('email', 'Email', 'email'), f('phone', 'Phone', 'text'),
      f('township', 'Township / delivery area', 'text'), f('company', 'Supplier company', 'text'), f('product', 'Product / interest / experience', 'textarea'),
      f('experience', 'Experience', 'textarea'), f('pledge_amount', 'Indicative amount (R)', 'number'), f('shop_address', 'Shop address', 'text'),
      f('approx_size', 'Approximate shop size', 'text'), f('expected_rent', 'Expected rent (R)', 'number'), f('expected_opening', 'Expected opening date', 'date'),
      f('photo_paths', 'Uploaded photo paths', 'array'), f('shop_id', 'Related shop UUID', 'text'), f('supplier_id', 'Published supplier UUID', 'text'),
    ], defaults: { role: 'landlord', status: 'new', name: '', photo_paths: [] },
  },
  {
    table: 'shops', label: 'Shop listings', description: 'Public shop spaces, their approval state, listing details and image gallery.', order: 'created_at',
    fields: [
      f('address', 'Address', 'text', { required: true }), f('city', 'Township / city', 'text', { required: true }), f('size', 'Size', 'text'),
      f('rent', 'Expected monthly rent (R)', 'number'), f('status', 'Listing status', 'text', { required: true }), f('score', 'Verification score / note', 'text'),
      f('owner', 'Public owner label', 'text'), f('suppliers_signed', 'Suppliers signed', 'number'), f('supplier_target', 'Supplier target', 'number'),
      f('description', 'Description', 'textarea'), f('hours', 'Trading hours', 'text'), f('expected_opening', 'Expected opening date', 'date'),
      f('tags', 'Tags (one per line)', 'array'), f('hardware_needs', 'Hardware needs (one per line)', 'array'),
      f('photo_views', 'Photo labels (one per line)', 'array'), f('photo_gallery', 'Public photo URLs / storage paths (one per line)', 'array'),
      f('approved', 'Publicly approved', 'boolean'), f('is_sample', 'Sample/test row', 'boolean'),
    ], defaults: { address: '', city: '', status: 'Pending review', approved: false, is_sample: false, tags: [], hardware_needs: [], photo_views: [], photo_gallery: [] },
  },
  {
    table: 'suppliers', label: 'Product suppliers', description: 'Approved product supplier directory, catalog images, prices and shop links.', order: 'created_at',
    fields: [f('company', 'Supplier / business name', 'text', { required: true }), f('product', 'Products supplied', 'text', { required: true }), f('price', 'Price (R)', 'number'),
      f('category', 'Category', 'text'), f('shop_id', 'Linked shop UUID', 'text'), f('photo_gallery', 'Product image URLs / storage paths (one per line)', 'array'),
      f('approved', 'Publicly approved', 'boolean'), f('is_sample', 'Sample/test row', 'boolean')],
    defaults: { company: '', product: '', approved: false, is_sample: false, photo_gallery: [] },
  },
  {
    table: 'hardware_assets', label: 'Hardware assets', description: 'Fit-out and equipment contributions awaiting review or published on the marketplace.', order: 'created_at',
    fields: [f('name', 'Contributor / business', 'text', { required: true }), f('type', 'Asset type', 'text', { required: true }), f('contribution', 'Contribution details', 'textarea', { required: true }),
      f('location', 'Location', 'text'), f('status', 'Status', 'text'), f('approved', 'Publicly approved', 'boolean'), f('is_sample', 'Sample/test row', 'boolean')],
    defaults: { name: '', type: 'Other fit-out', contribution: '', status: 'Pending review', approved: false, is_sample: false },
  },
  {
    table: 'community_posts', label: 'Community posts', description: 'Town-hall posts. Hidden posts remain private; make a post visible with the Hidden switch.', order: 'created_at',
    fields: [f('author', 'Author', 'text', { required: true }), f('role', 'Role', 'text'), f('location', 'Location', 'text'), f('content', 'Post content', 'textarea', { required: true }),
      f('likes', 'Likes', 'number'), f('hidden', 'Hidden from public', 'boolean'), f('is_sample', 'Sample/test row', 'boolean')],
    defaults: { author: '', role: 'Community member', content: '', likes: 0, hidden: true, is_sample: false },
  },
  {
    table: 'community_comments', label: 'Community comments', description: 'Individual town-hall comments and their public visibility.', order: 'created_at',
    fields: [f('post_id', 'Parent post UUID', 'text', { required: true }), f('author', 'Author', 'text', { required: true }), f('text', 'Comment', 'textarea', { required: true }), f('hidden', 'Hidden from public', 'boolean')],
    defaults: { post_id: '', author: '', text: '', hidden: true },
  },
  {
    table: 'shop_enquiries', label: 'Shop enquiries', description: 'Private contact enquiries, messages and follow-up state.', order: 'created_at',
    fields: [f('shop_code', 'Shop code', 'text', { required: true }), f('name', 'Contact name', 'text', { required: true }), f('phone', 'Phone', 'text', { required: true }),
      f('role', 'Enquirer role', 'text', { required: true }), f('message', 'Message', 'textarea'), f('handled', 'Handled', 'boolean')],
    defaults: { shop_code: '', name: '', phone: '', role: '', handled: false },
  },
  {
    table: 'pilot_stats', label: 'Pilot figures', description: 'Manually maintained pilot dashboard values. Update only verified values; the public app avoids presenting unverified totals.', order: 'id',
    fields: [f('pledged', 'Pledged (R)', 'number', { required: true }), f('goal', 'Goal (R)', 'number', { required: true }),
      f('hustlers', 'Hustlers', 'number', { required: true }), f('fill_rate', 'Fill rate (%)', 'number', { required: true })], defaults: { pledged: 0, goal: 25000, hustlers: 0, fill_rate: 0 },
  },
];
function f(name, label, type = 'text', extra = {}) { return { name, label, type, ...extra }; }
const format = (value) => value == null ? '—' : Array.isArray(value) ? (value.length ? value.join(', ') : '—') : typeof value === 'boolean' ? (value ? 'Yes' : 'No') : String(value);
const recordLabel = (resource, row) => {
  if (resource.table === 'shops') return `${row.code || 'Shop'} · ${row.address || 'No address'}`;
  if (resource.table === 'suppliers') return `${row.company || 'Supplier'} · ${row.product || ''}`;
  if (resource.table === 'join_applications') return `${row.name || 'Applicant'} · ${row.role || 'application'}`;
  if (resource.table === 'community_posts') return `${row.author || 'Post'} · ${(row.content || '').slice(0, 54)}`;
  if (resource.table === 'community_comments') return `${row.author || 'Comment'} · ${(row.text || '').slice(0, 54)}`;
  if (resource.table === 'shop_enquiries') return `${row.name || 'Enquiry'} · ${row.shop_code || ''}`;
  return [row.name, row.type, row.contribution, row.id].filter(Boolean).join(' · ') || 'Record';
};

export default function AdminConsole({ email, onSignOut, onDataChanged }) {
  const [activeTable, setActiveTable] = useState('join_applications');
  const [collections, setCollections] = useState({});
  const [loading, setLoading] = useState(false);
  const [loadingAll, setLoadingAll] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [editor, setEditor] = useState(null);
  const [notice, setNotice] = useState('');
  const [busyId, setBusyId] = useState('');
  const current = resources.find((item) => item.table === activeTable) || resources[0];
  const records = collections[current.table] || [];

  const fetchResource = useCallback(async (resource, quiet = false) => {
    if (!supabase) { setError('Supabase is not configured.'); return []; }
    if (!quiet) setLoading(true);
    setError('');
    const all = [];
    const chunk = 500;
    for (let offset = 0; offset < 10000; offset += chunk) {
      let request = supabase.from(resource.table).select('*').range(offset, offset + chunk - 1);
      if (resource.order === 'created_at') request = request.order('created_at', { ascending: false });
      else if (resource.order) request = request.order(resource.order, { ascending: true });
      const { data, error: fetchError } = await request;
      if (fetchError) { setError(`${resource.label} could not be loaded: ${fetchError.message}`); break; }
      all.push(...(data || []));
      if (!data || data.length < chunk) break;
    }
    setCollections((old) => ({ ...old, [resource.table]: all }));
    setLoading(false);
    return all;
  }, []);

  const refreshAll = useCallback(async () => {
    setLoadingAll(true);
    await Promise.all(resources.map((resource) => fetchResource(resource, true)));
    setLoadingAll(false);
  }, [fetchResource]);
  useEffect(() => { refreshAll(); }, [refreshAll]);
  useEffect(() => { setQuery(''); setError(''); if (!Object.prototype.hasOwnProperty.call(collections, current.table)) fetchResource(current); }, [activeTable]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return records;
    return records.filter((record) => JSON.stringify(record).toLowerCase().includes(term));
  }, [records, query]);
  const showNotice = (text) => { setNotice(text); window.setTimeout(() => setNotice(''), 5000); };

  const saveRecord = async (payload) => {
    setBusyId(editor?.record?.id || 'new'); setError('');
    const resource = editor.resource;
    const result = editor.record
      ? await supabase.from(resource.table).update(payload).eq('id', editor.record.id).select('*').maybeSingle()
      : await supabase.from(resource.table).insert(payload).select('*').single();
    if (result.error) { setError(`Could not save ${resource.label.toLowerCase()}: ${result.error.message}`); setBusyId(''); return false; }
    setEditor(null); setBusyId('');
    await fetchResource(resource, true);
    await onDataChanged?.();
    showNotice(`${resource.label.replace(/s$/, '')} saved.`);
    return true;
  };

  const deleteRecord = async (resource, row) => {
    const label = recordLabel(resource, row);
    if (!window.confirm(`Permanently delete “${label}”? This deletes the database record. Image files are retained so a photo shared by another record is not accidentally removed.`)) return;
    setBusyId(row.id); setError('');
    if (resource.table === 'community_posts') {
      const { error: childError } = await supabase.from('community_comments').delete().eq('post_id', row.id);
      if (childError) { setError(`Comments could not be removed: ${childError.message}`); setBusyId(''); return; }
    }
    const { error: deleteError } = await supabase.from(resource.table).delete().eq('id', row.id);
    if (deleteError) setError(`Could not delete this record: ${deleteError.message}`);
    else { await fetchResource(resource, true); await onDataChanged?.(); showNotice('Record deleted.'); }
    setBusyId('');
  };

  const review = async (row, decision) => {
    const verb = decision === 'approve' ? 'Approve and publish this listing? Uploaded photos will become public only after they are copied to the public listing bucket.' : 'Reject this application and keep it private?';
    if (!window.confirm(verb)) return;
    setBusyId(row.id); setError('');
    const promotedPaths = [];
    try {
      let publicPhotoPaths = null;
      if (decision === 'approve' && ['landlord', 'supplier'].includes(row.role)) {
        publicPhotoPaths = [];
        for (const originalPath of row.photo_paths || []) {
          if (!String(originalPath).startsWith('private/')) { publicPhotoPaths.push(originalPath); continue; }
          const { data: downloaded, error: downloadError } = await supabase.storage.from('join-photos').download(originalPath);
          if (downloadError || !downloaded) throw new Error(`Could not read a submitted photo for approval: ${downloadError?.message || 'download failed'}`);
          const folder = row.role === 'landlord' ? 'shops' : 'products';
          const safeFilename = String(originalPath).split('/').pop().replace(/[^a-z0-9._-]+/gi, '-');
          const publicPath = `${folder}/${row.id}/${crypto.randomUUID()}-${safeFilename}`;
          const { error: uploadError } = await supabase.storage.from('shop-photos').upload(publicPath, downloaded, { cacheControl: '3600', contentType: downloaded.type || 'image/jpeg', upsert: false });
          if (uploadError) throw new Error(`Could not publish a reviewed photo: ${uploadError.message}`);
          promotedPaths.push(publicPath);
          publicPhotoPaths.push(publicPath);
        }
      }
      const { data, error: rpcError } = await supabase.rpc('review_join_application', { p_application_id: row.id, p_decision: decision, p_public_photo_paths: publicPhotoPaths });
      if (rpcError) throw new Error(rpcError.message);
      await fetchResource(current, true);
      await onDataChanged?.();
      showNotice(decision === 'approve' ? (data?.shop_code ? `Shop ${data.shop_code} is now public.` : 'Application approved and its supplier listing and photo published.') : 'Application rejected and kept private.');
    } catch (reviewError) {
      if (promotedPaths.length) await supabase.storage.from('shop-photos').remove(promotedPaths);
      setError(`Review could not be saved: ${reviewError.message || 'Unknown error'}`);
    }
    setBusyId('');
  };

  const duplicateGroups = useMemo(() => {
    if (activeTable !== 'shops') return [];
    const groups = new Map();
    for (const row of records) {
      if (!row.approved || row.is_sample || !row.address) continue;
      const key = `${row.address.trim().toLowerCase()}|${(row.city || '').trim().toLowerCase()}`;
      groups.set(key, [...(groups.get(key) || []), row]);
    }
    return [...groups.values()].filter((group) => group.length > 1);
  }, [records, activeTable]);

  return <section className="section-pad page-section admin-console">
    <div className="admin-console-head"><div><div className="eyebrow">OLA! operations</div><h1>Admin workspace</h1><p>Signed in as <strong>{email || 'authorized administrator'}</strong>. Applicant contact details are visible only here.</p></div><div className="admin-head-actions"><button className="button button-small button-dark" onClick={refreshAll} disabled={loadingAll}><RefreshCw size={14} className={loadingAll ? 'spin-icon' : ''} /> Refresh data</button><button className="button button-small button-light" onClick={onSignOut}><LogOut size={14} /> Sign out</button></div></div>
    <div className="admin-console-layout"><aside className="admin-sidebar"><div className="admin-sidebar-title"><Database size={16} /> APP DATA</div>{resources.map((resource) => <button key={resource.table} className={`admin-side-link ${activeTable === resource.table ? 'active' : ''}`} onClick={() => setActiveTable(resource.table)}><span>{resource.label}</span><small>{collections[resource.table]?.length ?? '—'}</small></button>)}<div className="admin-security-note"><ShieldAlert size={16} /><span>Protected by Supabase Auth and row-level security. Public users cannot read private applications or enquiries.</span></div></aside>
      <div className="admin-data-area"><div className="admin-data-head"><div><div className="mini-label">DATA MANAGEMENT</div><h2>{current.label}</h2><p>{current.description}</p></div><div className="admin-data-actions"><button className="button button-small button-light" onClick={() => fetchResource(current)} disabled={loading}><RefreshCw size={14} className={loading ? 'spin-icon' : ''} /> Reload</button>{current.table !== 'pilot_stats' || records.length === 0 ? <button className="button button-small button-primary" onClick={() => setEditor({ resource: current, record: null })}><Plus size={15} /> New record</button> : null}</div></div>
        {duplicateGroups.map((group) => <div className="admin-warning" key={group.map((row) => row.id).join('-')}><ShieldAlert size={17} /><span><strong>Check for duplicate public listings:</strong> {group.map((row) => row.code || row.id).join(', ')} share the same address and area. Nothing was deleted or hidden automatically.</span></div>)}
        {error && <div className="admin-inline-error" role="alert">{error}</div>}
        <div className="admin-table-tools"><div className="admin-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={`Search ${current.label.toLowerCase()}…`} /></div><span>{loading ? 'Loading…' : `${filtered.length} of ${records.length} records`}</span></div>
        {loadingAll && !Object.prototype.hasOwnProperty.call(collections, current.table) ? <div className="admin-empty"><LoaderCircle size={20} className="spin-icon" /> Loading records…</div> : filtered.length ? <div className="admin-record-list">{filtered.map((row) => <AdminRecord key={row.id} resource={current} row={row} busy={busyId === row.id} onEdit={() => setEditor({ resource: current, record: row })} onDelete={() => deleteRecord(current, row)} onReview={(decision) => review(row, decision)} />)}</div> : <div className="admin-empty"><ClipboardList size={22} /><strong>{query ? 'No matching records.' : `No ${current.label.toLowerCase()} yet.`}</strong><span>Create a record or submit it through the public app.</span></div>}
      </div>
    </div>
    {notice && <div className="admin-toast" role="status"><Check size={15} /> {notice}</div>}
    {editor && <RecordEditor resource={editor.resource} record={editor.record} busy={busyId !== ''} onClose={() => setEditor(null)} onSave={saveRecord} />}
  </section>;
}

function AdminRecord({ resource, row, busy, onEdit, onDelete, onReview }) {
  const title = recordLabel(resource, row);
  const [pictures, setPictures] = useState([]);
  useEffect(() => {
    let active = true;
    (async () => {
      const paths = [...(Array.isArray(row.photo_gallery) ? row.photo_gallery : []), ...(Array.isArray(row.photo_paths) ? row.photo_paths : [])].filter(Boolean);
      const urls = [];
      for (const path of paths) {
        if (String(path).startsWith('private/')) {
          const { data, error } = await supabase.storage.from('join-photos').createSignedUrl(path, 3600);
          if (!error && data?.signedUrl) urls.push(data.signedUrl);
        } else { const url = publicOlaImageUrl(path); if (url) urls.push(url); }
      }
      if (active) setPictures([...new Set(urls)]);
    })();
    return () => { active = false; };
  }, [row]);
  const pending = resource.table === 'join_applications' && ['new', 'reviewing'].includes(row.status);
  const visibleFields = resource.fields.slice(0, 4).filter((field) => row[field.name] != null && row[field.name] !== '');
  return <article className="admin-record-card">
    <div className="admin-record-top"><div><strong>{title}</strong><small>{row.status || (row.approved ? 'Approved' : row.hidden ? 'Hidden' : 'Record')} · {row.created_at ? new Date(row.created_at).toLocaleString() : `ID ${row.id}`}</small></div><div className="admin-record-actions">{pending && <><button className="button button-small button-primary" onClick={() => onReview('approve')} disabled={busy}><Check size={14} /> Approve & publish</button><button className="button button-small button-light" onClick={() => onReview('reject')} disabled={busy}><X size={14} /> Reject</button></>}<button className="icon-action" title="Edit record" onClick={onEdit}><Edit3 size={15} /></button><button className="icon-action danger" title="Delete record" onClick={onDelete} disabled={busy}>{busy ? <LoaderCircle size={15} className="spin-icon" /> : <Trash2 size={15} />}</button></div></div>
    <div className="admin-record-preview">{visibleFields.map((field) => <div key={field.name}><small>{field.label}</small><span>{format(row[field.name])}</span></div>)}</div>
    {pictures.length > 0 && <div className="admin-photo-strip">{pictures.map((src, index) => <a key={`${src}-${index}`} href={src} target="_blank" rel="noreferrer" title="Open original image"><img src={src} alt={`${resource.label} photo ${index + 1}`} loading="lazy" /></a>)}</div>}
    <details className="admin-record-details"><summary><Eye size={14} /> View all fields <ChevronDown size={14} /></summary><div className="admin-field-grid">{Object.entries(row).map(([key, value]) => <div key={key} className={Array.isArray(value) || String(value ?? '').length > 90 ? 'wide' : ''}><small>{key}</small><span>{format(value)}</span></div>)}</div></details>
  </article>;
}

function RecordEditor({ resource, record, busy, onClose, onSave }) {
  const editable = resource.fields;
  const [values, setValues] = useState(() => ({ ...resource.defaults, ...(record || {}) }));
  const [localError, setLocalError] = useState('');
  const change = (name, value) => setValues((current) => ({ ...current, [name]: value }));
  const submit = async (event) => {
    event.preventDefault(); setLocalError('');
    const payload = {};
    for (const field of editable) {
      let value = values[field.name];
      if (field.type === 'array') value = Array.isArray(value) ? value : String(value || '').split('\n').map((part) => part.trim()).filter(Boolean);
      if (field.type === 'number') value = value === '' || value == null ? null : Number(value);
      if (field.type === 'boolean') value = Boolean(value);
      if (field.type === 'date') value = value || null;
      if (typeof value === 'string') value = value.trim() || null;
      if (field.required && (value == null || value === '')) { setLocalError(`${field.label} is required.`); return; }
      payload[field.name] = value;
    }
    const ok = await onSave(payload);
    if (!ok) setLocalError('Save failed. See the database error above.');
  };
  return <div className="admin-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="admin-editor" role="dialog" aria-modal="true" aria-labelledby="admin-editor-title"><div className="admin-editor-head"><div><div className="mini-label">{record ? 'EDIT RECORD' : 'CREATE RECORD'}</div><h2 id="admin-editor-title">{record ? recordLabel(resource, record) : `New ${resource.label.replace(/s$/, '').toLowerCase()}`}</h2><p>Changes save directly to the connected OLA database.</p></div><button className="icon-action" type="button" onClick={onClose} aria-label="Close editor"><X size={18} /></button></div><form onSubmit={submit}><div className="admin-editor-fields">{editable.map((field) => <label key={field.name} className={`admin-editor-field ${['textarea', 'array'].includes(field.type) ? 'wide' : ''}`}><span>{field.label}{field.required ? ' *' : ''}</span>{field.type === 'boolean' ? <span className="admin-toggle"><input type="checkbox" checked={Boolean(values[field.name])} onChange={(event) => change(field.name, event.target.checked)} /> {values[field.name] ? 'Yes' : 'No'}</span> : field.type === 'select' ? <select value={values[field.name] ?? ''} onChange={(event) => change(field.name, event.target.value)}>{field.options.map((option) => <option key={option} value={option}>{option}</option>)}</select> : field.type === 'textarea' || field.type === 'array' ? <textarea rows={field.type === 'array' ? 3 : 5} value={Array.isArray(values[field.name]) ? values[field.name].join('\n') : (values[field.name] ?? '')} placeholder={field.type === 'array' ? 'One value per line' : ''} onChange={(event) => change(field.name, field.type === 'array' ? event.target.value.split('\n') : event.target.value)} /> : <input type={field.type} value={field.type === 'date' ? String(values[field.name] || '').slice(0, 10) : values[field.name] ?? ''} onChange={(event) => change(field.name, event.target.value)} />}</label>)}</div>{resource.table === 'join_applications' && <p className="admin-editor-help">Use the record’s “Approve &amp; publish” or “Reject” control for the status workflow. Status and IDs cannot be changed directly.</p>}{localError && <div className="admin-inline-error">{localError}</div>}<div className="admin-editor-footer"><button type="button" className="button button-light" onClick={onClose} disabled={busy}>Cancel</button><button type="submit" className="button button-primary" disabled={busy}>{busy ? <><LoaderCircle size={15} className="spin-icon" /> Saving…</> : <><Check size={15} /> Save record</>}</button></div></form></section></div>;
}
