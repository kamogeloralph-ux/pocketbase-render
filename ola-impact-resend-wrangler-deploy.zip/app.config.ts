export default { logoUrl: "https://rovaya.co.za/logo.svg" }
