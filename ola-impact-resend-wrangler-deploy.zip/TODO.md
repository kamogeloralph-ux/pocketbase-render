# OLA! delivery status

## 2026-11-08 follow-up
- [x] Keep asset/hardware submission on Join the hustle; allow up to 4 private condition photos so reviewers can see asset state.
- [x] Allow supplier/product submissions to select up to 4 photos; retain the existing required-photo behavior.
- [x] Add up to 4 shop-space photos and a Contact Us destination in the navigation menu.
- [x] Add a Contact Us form that sends messages through the existing server-side email notification endpoint.
- [x] Add the additive hardware photo-path migration and admin private-photo preview support.
- [x] Applied the additive hardware asset photo-path migration to the OLA Supabase project before deploying the updated app.

## Completed in this update
- [x] Replaced the legacy visual mark with the supplied OLA logo assets across the app chrome and kept PWA/social assets aligned with the handover.
- [x] Replaced public-facing “maker” wording with “product supplier” terminology.
- [x] Fixed `/admin` successful allowlist verification so an authorized Supabase Auth session reaches the admin workspace.
- [x] Added the full authenticated operations console: read/search all fields, create, edit and delete records for applications, shops, suppliers, hardware, community posts/comments, shop enquiries and pilot figures.
- [x] Kept public reads limited to approved/non-sample listings and visible community content; submissions still require Supabase persistence.
- [x] Moved new applicant shop/product photos to the private `join-photos` bucket. Public users may upload only beneath its `private/` prefix; only admins may read, using signed URLs.
- [x] Added approval-time copying into public `shop-photos`, sent only those public paths to the admin-only review RPC, and kept rejected/private submission photos out of public listings.
- [x] Connected real approved shop photos to cards, detail galleries and product-supplier shop previews; connected approved supplier photos to the supplier catalogue.
- [x] Added explicit authenticated table CRUD and sequence grants, while preserving RLS admin-only mutation policies and the private-photo admin read policy.
- [x] Applied all latest additive schema/storage migrations to the connected OLA Supabase project; the supplied admin UID membership was verified.
- [x] Verified anonymous REST reads return zero application/enquiry rows; verified two approved shop galleries each return HTTP 200.
- [x] Verified the full Vite production build succeeds and the admin route is present in `manus-routes.json`.

## Owner decisions / release still required
- [ ] Decide whether public shop listings OLA-107 and OLA-108 at the same address/area are intentional or whether one should be removed. The app flags this; neither listing was deleted or hidden.
- [ ] Upload the final prebuilt Pages ZIP to Cloudflare Pages project `ola` Production. The connected Cloudflare credential can inspect project details but lacks asset-upload permission; the live site still uses its previous frontend until a new Direct Upload is deployed.
- [ ] Test a real admin sign-in and one real submission from the owner’s browser. No password was supplied; no synthetic production submission was created for testing.
- [ ] Consider server-verified abuse protection before broad public promotion. Do not store payment credentials or identity documents in the photo buckets.

The connected app remains non-payment processing. Investor amounts are non-binding interest only; no money is collected.
