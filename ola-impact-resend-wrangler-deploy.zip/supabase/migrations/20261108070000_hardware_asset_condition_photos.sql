-- Store private review-photo paths for hardware and fit-out submissions.
-- The uploaded objects remain in the existing private join-photos bucket.
ALTER TABLE public.hardware_assets
  ADD COLUMN IF NOT EXISTS photo_paths text[] NOT NULL DEFAULT '{}'::text[];

-- Public users may include photo paths when submitting a pending hardware asset;
-- existing row-level policies still force new records to remain unapproved.
GRANT INSERT (name, type, contribution, location, photo_paths, status, approved, is_sample)
  ON public.hardware_assets TO anon, authenticated;
