-- Incremental safety and data-quality migration for the existing OLA project.
-- It does not delete or rewrite rows. Existing rows flagged is_sample=true remain
-- in the database but are no longer visible to public API clients.

-- Remove unsubstantiated defaults so new approved listings cannot inherit demo-like values.
ALTER TABLE public.shops
  ALTER COLUMN city DROP DEFAULT,
  ALTER COLUMN size DROP DEFAULT,
  ALTER COLUMN size DROP NOT NULL,
  ALTER COLUMN rent DROP DEFAULT,
  ALTER COLUMN rent DROP NOT NULL,
  ALTER COLUMN status SET DEFAULT 'Pending review',
  ALTER COLUMN score DROP DEFAULT,
  ALTER COLUMN score DROP NOT NULL,
  ALTER COLUMN suppliers_signed DROP DEFAULT,
  ALTER COLUMN suppliers_signed DROP NOT NULL,
  ALTER COLUMN supplier_target DROP DEFAULT,
  ALTER COLUMN supplier_target DROP NOT NULL,
  ALTER COLUMN description DROP DEFAULT,
  ALTER COLUMN description DROP NOT NULL,
  ALTER COLUMN hours DROP DEFAULT,
  ALTER COLUMN hours DROP NOT NULL,
  ALTER COLUMN tags SET DEFAULT '{}',
  ALTER COLUMN hardware_needs SET DEFAULT '{}',
  ALTER COLUMN photo_views SET DEFAULT '{}';

ALTER TABLE public.suppliers
  ALTER COLUMN price DROP DEFAULT,
  ALTER COLUMN price DROP NOT NULL,
  ALTER COLUMN category DROP DEFAULT,
  ALTER COLUMN category DROP NOT NULL;

ALTER TABLE public.hardware_assets
  ALTER COLUMN status SET DEFAULT 'Pending review';

ALTER TABLE public.community_posts
  ALTER COLUMN hidden SET DEFAULT true;

ALTER TABLE public.community_comments
  ALTER COLUMN hidden SET DEFAULT true;

-- Public table grants are limited to fields actually used by the app.
-- This excludes private owner/contact/internal columns from anonymous API access.
REVOKE SELECT ON public.shops, public.suppliers, public.hardware_assets,
  public.community_posts, public.community_comments FROM PUBLIC, anon, authenticated;
GRANT SELECT (id, code, address, city, size, rent, status, score, description,
  hours, tags, hardware_needs, photo_views, photo_gallery, created_at, approved, is_sample)
  ON public.shops TO anon, authenticated;
GRANT SELECT (id, company, product, price, category, created_at, approved, is_sample)
  ON public.suppliers TO anon, authenticated;
GRANT SELECT (id, name, type, contribution, location, status, created_at, approved, is_sample)
  ON public.hardware_assets TO anon, authenticated;
GRANT SELECT (id, author, role, location, content, likes, created_at, hidden, is_sample)
  ON public.community_posts TO anon, authenticated;
GRANT SELECT (id, post_id, author, text, created_at, hidden)
  ON public.community_comments TO anon, authenticated;

-- Hide sample records even when a client queries the REST API directly.
DROP POLICY IF EXISTS "Read approved shops" ON public.shops;
CREATE POLICY "Read approved shops" ON public.shops
  FOR SELECT TO anon, authenticated
  USING (approved = true AND is_sample = false);

DROP POLICY IF EXISTS "Read approved suppliers" ON public.suppliers;
CREATE POLICY "Read approved suppliers" ON public.suppliers
  FOR SELECT TO anon, authenticated
  USING (approved = true AND is_sample = false);

DROP POLICY IF EXISTS "Read approved hardware" ON public.hardware_assets;
CREATE POLICY "Read approved hardware" ON public.hardware_assets
  FOR SELECT TO anon, authenticated
  USING (approved = true AND is_sample = false);

DROP POLICY IF EXISTS "Anyone can read visible posts" ON public.community_posts;
CREATE POLICY "Anyone can read visible posts" ON public.community_posts
  FOR SELECT TO anon, authenticated
  USING (hidden = false AND is_sample = false);

DROP POLICY IF EXISTS "Anyone can read visible comments" ON public.community_comments;
CREATE POLICY "Anyone can read visible comments" ON public.community_comments
  FOR SELECT TO anon, authenticated
  USING (
    hidden = false
    AND EXISTS (
      SELECT 1 FROM public.community_posts p
      WHERE p.id = post_id AND p.hidden = false AND p.is_sample = false
    )
  );

-- Public submissions stay private until an admin approves/unhides them.
DROP POLICY IF EXISTS "Anyone can post" ON public.community_posts;
CREATE POLICY "Anyone can post" ON public.community_posts
  FOR INSERT TO anon, authenticated
  WITH CHECK (hidden = true AND likes = 0 AND is_sample = false);

DROP POLICY IF EXISTS "Anyone can comment" ON public.community_comments;
CREATE POLICY "Anyone can comment" ON public.community_comments
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    hidden = true
    AND EXISTS (
      SELECT 1 FROM public.community_posts p
      WHERE p.id = post_id AND p.hidden = false AND p.is_sample = false
    )
  );

DROP POLICY IF EXISTS "Submit hardware for approval" ON public.hardware_assets;
CREATE POLICY "Submit hardware for approval" ON public.hardware_assets
  FOR INSERT TO anon, authenticated
  WITH CHECK (approved = false AND status = 'Pending review' AND is_sample = false);

DROP POLICY IF EXISTS "Submit shop for approval" ON public.shops;
CREATE POLICY "Submit shop for approval" ON public.shops
  FOR INSERT TO anon, authenticated
  WITH CHECK (approved = false AND status = 'Pending review' AND is_sample = false);

DROP POLICY IF EXISTS "Submit supplier for approval" ON public.suppliers;
CREATE POLICY "Submit supplier for approval" ON public.suppliers
  FOR INSERT TO anon, authenticated
  WITH CHECK (approved = false AND is_sample = false);

-- Do not expose the unused default pilot goal through a public table policy or RPC.
DROP POLICY IF EXISTS "Read pilot stats" ON public.pilot_stats;
REVOKE SELECT ON public.pilot_stats FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.pilot_summary() FROM PUBLIC, anon, authenticated;

-- Keep the existing narrow like RPC, but prevent it from modifying sample posts.
CREATE OR REPLACE FUNCTION public.like_post(p_post_id uuid)
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = ''
AS $$
  UPDATE public.community_posts
     SET likes = likes + 1
   WHERE id = p_post_id AND hidden = false AND is_sample = false
  RETURNING likes;
$$;
REVOKE EXECUTE ON FUNCTION public.like_post(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.like_post(uuid) TO anon, authenticated;
