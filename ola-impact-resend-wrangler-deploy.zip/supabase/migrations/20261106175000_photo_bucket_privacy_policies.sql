-- New uploads go into the private application bucket under the private/ prefix.
drop policy if exists "Anyone can upload join photos" on storage.objects;
create policy "Anyone can submit private photos"
  on storage.objects for insert to anon, authenticated
  with check (
    bucket_id = 'join-photos'
    and (storage.foldername(name))[1] = 'private'
  );

-- The public bucket is now only populated by authenticated allowlisted admins during approval.
drop policy if exists "Anyone can upload shop photos" on storage.objects;
drop policy if exists "Admins upload approved shop photos" on storage.objects;
create policy "Admins upload approved shop photos"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'shop-photos' and public.is_admin());
