-- UID-based OLA administrator membership; populate only trusted auth.users IDs separately.
create table if not exists public.ola_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.ola_admins enable row level security;
revoke all on table public.ola_admins from public, anon, authenticated;
grant select on table public.ola_admins to authenticated;
drop policy if exists "Admins can verify own membership" on public.ola_admins;
create policy "Admins can verify own membership"
  on public.ola_admins for select to authenticated
  using (auth.uid() = user_id);

-- Keep existing email-admin authorization while adding the UID allowlist.
create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = ''
as $function$
  select exists (
    select 1 from public.admin_emails
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  ) or exists (
    select 1 from public.ola_admins where user_id = auth.uid()
  )
$function$;
revoke execute on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

-- Review and promotion are atomic; contact fields are never copied to public records.
create or replace function public.review_join_application(p_application_id uuid, p_decision text)
returns jsonb
language plpgsql security definer set search_path = ''
as $function$
declare
  application_row public.join_applications%rowtype;
  created_record_id uuid;
  created_record_code text;
  photo_labels text[] := array[]::text[];
  photo_index integer := 0;
begin
  if not public.is_admin() then raise exception 'Admin access required'; end if;
  if p_decision is null or p_decision not in ('approve', 'reject') then
    raise exception 'Unsupported decision';
  end if;
  select * into application_row
    from public.join_applications
    where id = p_application_id
    for update;
  if not found then raise exception 'Application not found'; end if;
  if application_row.status not in ('new', 'reviewing') then
    raise exception 'Application is no longer awaiting review';
  end if;
  if p_decision = 'reject' then
    update public.join_applications set status = 'rejected' where id = application_row.id;
    return jsonb_build_object('application_id', application_row.id, 'status', 'rejected');
  end if;
  if application_row.role = 'landlord' then
    foreach photo_index in array coalesce(array(select generate_series(1, cardinality(application_row.photo_paths))), array[]::integer[]) loop
      photo_labels := array_append(photo_labels, 'Shop photo ' || photo_index::text);
    end loop;
    insert into public.shops (
      address, city, size, rent, status, photo_views, photo_gallery,
      approved, is_sample, expected_opening
    ) values (
      application_row.shop_address, application_row.township,
      application_row.approx_size, application_row.expected_rent,
      'Approved', photo_labels, application_row.photo_paths,
      true, false, application_row.expected_opening
    ) returning id, code into created_record_id, created_record_code;
    update public.join_applications set status = 'approved', shop_id = created_record_id
      where id = application_row.id;
  elsif application_row.role = 'supplier' then
    insert into public.suppliers(company, product, price, category, approved, is_sample)
    values (application_row.company, application_row.product, null, null, true, false)
    returning id into created_record_id;
    update public.join_applications set status = 'approved', supplier_id = created_record_id
      where id = application_row.id;
  else
    update public.join_applications set status = 'approved' where id = application_row.id;
  end if;
  return jsonb_build_object(
    'application_id', application_row.id, 'status', 'approved',
    'record_id', created_record_id, 'shop_code', created_record_code
  );
end;
$function$;
revoke all on function public.review_join_application(uuid, text) from public, anon;
grant execute on function public.review_join_application(uuid, text) to authenticated;
