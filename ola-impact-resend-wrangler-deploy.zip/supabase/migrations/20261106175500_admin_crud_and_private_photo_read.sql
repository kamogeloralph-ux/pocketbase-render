-- The admin console uses direct table CRUD. RLS still limits rows and writes to allowlisted admins.
grant select, insert, update, delete on table
  public.join_applications,
  public.shops,
  public.suppliers,
  public.hardware_assets,
  public.community_posts,
  public.community_comments,
  public.shop_enquiries,
  public.pilot_stats
  to authenticated;

do $migration$
declare
  sequence_name text;
begin
  foreach sequence_name in array array[
    pg_get_serial_sequence('public.shops', 'code'),
    pg_get_serial_sequence('public.pilot_stats', 'id')
  ] loop
    if sequence_name is not null then
      execute format('grant usage, select on sequence %s to authenticated', sequence_name);
    end if;
  end loop;
end;
$migration$;

-- Pending uploads are private. Only OLA admins may read objects to review or promote them.
drop policy if exists "Admins read join photos" on storage.objects;
create policy "Admins read join photos"
  on storage.objects for select to authenticated
  using (bucket_id = 'join-photos' and public.is_admin());
