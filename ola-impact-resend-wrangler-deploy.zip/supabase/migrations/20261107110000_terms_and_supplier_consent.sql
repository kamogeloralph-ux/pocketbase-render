-- Additive, review-only migration for Terms and supplier consent capture.
-- Do not apply to production until the Terms copy and application flow are approved.

ALTER TABLE public.join_applications
  ADD COLUMN IF NOT EXISTS terms_version text,
  ADD COLUMN IF NOT EXISTS terms_accepted_at timestamptz,
  ADD COLUMN IF NOT EXISTS supplier_class text,
  ADD COLUMN IF NOT EXISTS supplier_terms_version text,
  ADD COLUMN IF NOT EXISTS supplier_terms_accepted_at timestamptz;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'join_applications_supplier_class_check'
      AND conrelid = 'public.join_applications'::regclass
  ) THEN
    ALTER TABLE public.join_applications
      ADD CONSTRAINT join_applications_supplier_class_check
      CHECK (supplier_class IS NULL OR supplier_class IN ('local_micro', 'enterprise_wholesale'));
  END IF;
END
$$;
