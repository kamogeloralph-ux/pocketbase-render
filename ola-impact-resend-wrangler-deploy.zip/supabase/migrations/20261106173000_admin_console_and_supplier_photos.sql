-- Product suppliers receive their submitted product images only after approval.
alter table public.suppliers
  add column if not exists photo_gallery text[] not null default array[]::text[],
  add column if not exists shop_id uuid;

do $migration$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'suppliers_shop_id_fkey'
      and conrelid = 'public.suppliers'::regclass
  ) then
    alter table public.suppliers
      add constraint suppliers_shop_id_fkey
      foreign key (shop_id) references public.shops(id) on delete set null;
  end if;
end;
$migration$;

-- Authenticated users still see only rows allowed by the existing RLS policies.
-- Admins need full row reads to operate the private admin data console.
grant select on table public.join_applications to authenticated;
grant select on table public.shops to authenticated;
grant select on table public.suppliers to authenticated;
grant select on table public.hardware_assets to authenticated;
grant select on table public.community_posts to authenticated;
grant select on table public.community_comments to authenticated;
grant select on table public.shop_enquiries to authenticated;
grant select on table public.pilot_stats to authenticated;
grant select (photo_gallery, shop_id) on table public.suppliers to anon, authenticated;

-- Allow only allowlisted administrators to replace/remove uploaded public shop/product images.
drop policy if exists "Admins manage shop photos" on storage.objects;
create policy "Admins manage shop photos"
  on storage.objects for all to authenticated
  using (bucket_id = 'shop-photos' and public.is_admin())
  with check (bucket_id = 'shop-photos' and public.is_admin());

-- Approval remains transactional and private applicant contact details stay out of public tables.
create or replace function public.review_join_application(p_application_id uuid, p_decision text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $function$
declare
  application_row public.join_applications%rowtype;
  created_record_id uuid;
  created_record_code text;
  photo_labels text[] := array[]::text[];
  photo_index integer := 0;
begin
  if not public.is_admin() then
    raise exception 'Admin access required';
  end if;
  if p_decision is null or p_decision not in ('approve', 'reject') then
    raise exception 'Unsupported decision';
  end if;
  select * into application_row
  from public.join_applications
  where id = p_application_id
  for update;
  if not found then raise exception 'Application not found'; end if;
  if application_row.status not in ('new', 'reviewing') then
    raise exception 'Application is no longer awaiting review';
  end if;
  if p_decision = 'reject' then
    update public.join_applications set status = 'rejected' where id = application_row.id;
    return jsonb_build_object('application_id', application_row.id, 'status', 'rejected');
  end if;
  if application_row.role = 'landlord' then
    foreach photo_index in array coalesce(
      array(select generate_series(1, cardinality(application_row.photo_paths))),
      array[]::integer[]
    ) loop
      photo_labels := array_append(photo_labels, 'Shop photo ' || photo_index::text);
    end loop;
    insert into public.shops (
      address, city, size, rent, status, photo_views, photo_gallery,
      approved, is_sample, expected_opening
    ) values (
      application_row.shop_address, application_row.township,
      application_row.approx_size, application_row.expected_rent,
      'Approved', photo_labels, application_row.photo_paths,
      true, false, application_row.expected_opening
    ) returning id, code into created_record_id, created_record_code;
    update public.join_applications
      set status = 'approved', shop_id = created_record_id
      where id = application_row.id;
  elsif application_row.role = 'supplier' then
    insert into public.suppliers(
      company, product, price, category, approved, is_sample,
      photo_gallery, shop_id
    ) values (
      application_row.company, application_row.product, null, null,
      true, false, application_row.photo_paths,
      application_row.shop_id
    ) returning id into created_record_id;
    update public.join_applications
      set status = 'approved', supplier_id = created_record_id
      where id = application_row.id;
  else
    update public.join_applications set status = 'approved' where id = application_row.id;
  end if;
  return jsonb_build_object(
    'application_id', application_row.id,
    'status', 'approved',
    'record_id', created_record_id,
    'shop_code', created_record_code
  );
end;
$function$;
revoke all on function public.review_join_application(uuid, text) from public, anon;
grant execute on function public.review_join_application(uuid, text) to authenticated;
