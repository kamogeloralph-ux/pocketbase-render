-- Replace the two-argument approval RPC with a version that accepts explicitly promoted public paths.
-- Private 'private/...' objects can never be copied into public listing rows by the RPC itself.
drop function if exists public.review_join_application(uuid, text);

create function public.review_join_application(
  p_application_id uuid,
  p_decision text,
  p_public_photo_paths text[] default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $function$
declare
  application_row public.join_applications%rowtype;
  created_record_id uuid;
  created_record_code text;
  photo_labels text[] := array[]::text[];
  photo_index integer := 0;
  public_paths text[];
begin
  if not public.is_admin() then raise exception 'Admin access required'; end if;
  if p_decision is null or p_decision not in ('approve', 'reject') then raise exception 'Unsupported decision'; end if;
  select * into application_row
  from public.join_applications
  where id = p_application_id
  for update;
  if not found then raise exception 'Application not found'; end if;
  if application_row.status not in ('new', 'reviewing') then
    raise exception 'Application is no longer awaiting review';
  end if;
  if p_decision = 'reject' then
    update public.join_applications set status = 'rejected' where id = application_row.id;
    return jsonb_build_object('application_id', application_row.id, 'status', 'rejected');
  end if;
  if application_row.role in ('landlord', 'supplier') then
    if p_public_photo_paths is null and exists (
      select 1 from unnest(coalesce(application_row.photo_paths, array[]::text[])) path
      where path like 'private/%'
    ) then
      raise exception 'Private submission photos must be copied by the authorized admin console before approval';
    end if;
    public_paths := coalesce(p_public_photo_paths, application_row.photo_paths, array[]::text[]);
    if exists (select 1 from unnest(public_paths) path where path like 'private/%') then
      raise exception 'A private photo path cannot be published';
    end if;
  else
    public_paths := array[]::text[];
  end if;
  if application_row.role = 'landlord' then
    foreach photo_index in array coalesce(
      array(select generate_series(1, cardinality(public_paths))),
      array[]::integer[]
    ) loop
      photo_labels := array_append(photo_labels, 'Shop photo ' || photo_index::text);
    end loop;
    insert into public.shops (
      address, city, size, rent, status, photo_views, photo_gallery,
      approved, is_sample, expected_opening
    ) values (
      application_row.shop_address, application_row.township,
      application_row.approx_size, application_row.expected_rent,
      'Approved', photo_labels, public_paths,
      true, false, application_row.expected_opening
    ) returning id, code into created_record_id, created_record_code;
    update public.join_applications
      set status = 'approved', shop_id = created_record_id
      where id = application_row.id;
  elsif application_row.role = 'supplier' then
    insert into public.suppliers(
      company, product, price, category, approved, is_sample,
      photo_gallery, shop_id
    ) values (
      application_row.company, application_row.product, null, null,
      true, false, public_paths,
      application_row.shop_id
    ) returning id into created_record_id;
    update public.join_applications
      set status = 'approved', supplier_id = created_record_id
      where id = application_row.id;
  else
    update public.join_applications set status = 'approved' where id = application_row.id;
  end if;
  return jsonb_build_object(
    'application_id', application_row.id,
    'status', 'approved',
    'record_id', created_record_id,
    'shop_code', created_record_code
  );
end;
$function$;
revoke all on function public.review_join_application(uuid, text, text[]) from public, anon;
grant execute on function public.review_join_application(uuid, text, text[]) to authenticated;
