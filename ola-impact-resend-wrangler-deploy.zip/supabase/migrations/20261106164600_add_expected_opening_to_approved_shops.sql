-- Store the submitted expected opening date on public shop listings so it is not lost during approval.
alter table public.shops add column if not exists expected_opening date;
grant select (expected_opening) on public.shops to anon, authenticated;
