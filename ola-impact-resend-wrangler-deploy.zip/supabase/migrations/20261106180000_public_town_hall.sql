-- Town hall is a public conversation space: posts and comments are visible
-- immediately and do not depend on admin review or hidden flags.
ALTER TABLE public.community_posts ALTER COLUMN hidden SET DEFAULT false;
ALTER TABLE public.community_comments ALTER COLUMN hidden SET DEFAULT false;

DROP POLICY IF EXISTS "Anyone can read visible posts" ON public.community_posts;
CREATE POLICY "Anyone can read town hall posts" ON public.community_posts
  FOR SELECT TO anon, authenticated
  USING (is_sample = false);

DROP POLICY IF EXISTS "Anyone can read visible comments" ON public.community_comments;
CREATE POLICY "Anyone can read town hall comments" ON public.community_comments
  FOR SELECT TO anon, authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.community_posts p
      WHERE p.id = post_id AND p.is_sample = false
    )
  );

DROP POLICY IF EXISTS "Anyone can post" ON public.community_posts;
CREATE POLICY "Anyone can post publicly to town hall" ON public.community_posts
  FOR INSERT TO anon, authenticated
  WITH CHECK (hidden = false AND likes = 0 AND is_sample = false);

DROP POLICY IF EXISTS "Anyone can comment" ON public.community_comments;
CREATE POLICY "Anyone can comment publicly in town hall" ON public.community_comments
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    hidden = false
    AND EXISTS (
      SELECT 1 FROM public.community_posts p
      WHERE p.id = post_id AND p.is_sample = false
    )
  );
